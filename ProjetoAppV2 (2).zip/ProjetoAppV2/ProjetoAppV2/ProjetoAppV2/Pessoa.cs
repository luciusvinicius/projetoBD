﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Pessoa: Entidade
    {
        private String _numContribuinte;
        private String _numCC;
        private String _genero;
        private String _dataNascimento;
        private String _inicioExercicio;
        private String _fimExercicio;
        private String _fracao;

        public Pessoa(String i, String t, String n, String em, String end) : base(i, t, n, em, end)
        {
           
        }

        public String ToString() {
            return base.Nome;
        }
        public String NumContribuinte
        {
            get { return _numContribuinte; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O número de contribuinte não pode ser null.");
                    //return;
                }
                _numContribuinte = value;
            }
        }
        public String Fracao
        {
            get { return _fracao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A fração não pode ser null.");
                    //return;
                }
                _fracao = value;
            }
        }

        public String NumCC
        {
            get { return _numCC; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O número de CC não pode ser null.");
                    //return;
                }
                _numCC = value;
            }
        }
        public String InicioExercicio
        {
            get { return _inicioExercicio; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O início de exercício não pode ser null.");
                }
                _inicioExercicio = value;
            }
        }

        public String FimExercicio
        {
            get { return _fimExercicio; }
            set { _fimExercicio = value; }
        }

        public String Genero
        {
            get { return _genero; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O genero não pode ser null.");
                    //return;
                }
                _genero = value;
            }
        }

        public String DataNascimento
        {
            get { return _dataNascimento; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A data de nascimento não pode ser null.");
                    //return;
                }
                _dataNascimento = value;
            }
        }
    }
}

