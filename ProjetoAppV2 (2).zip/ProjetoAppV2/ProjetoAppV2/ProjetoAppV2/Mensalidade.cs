﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Mensalidade
    {
        private String ano;
        private String valor;
        private String descricao;
        private String fracao;
        private String entidade;
        private String condominio;

        public override string ToString()
        {
            return valor + " - " + descricao;
        }
        public String Ano
        {
            get { return ano; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O ano não pode ser null.");
                }
                fracao = value;
            }
        }
        public String Valor
        {
            get { return valor; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O valor da mensalidade não pode ser null.");
                }
                valor = value;
            }
        }

        public String Descricao
        {
            get { return descricao; }
            set
            {
                descricao = value;
            }
        }

        public String Fracap
        {
            get { return fracao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A fração não pode ser null.");
                }
                fracao = value;
            }
        }
        public String Condominio
        {
            get { return condominio; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O condominio não pode ser null.");
                }
                condominio = value;
            }
        }
        public String Entidade
        {
            get { return entidade; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A entidade não pode ser null.");
                }
                entidade = value;
            }
        }
    }
}
