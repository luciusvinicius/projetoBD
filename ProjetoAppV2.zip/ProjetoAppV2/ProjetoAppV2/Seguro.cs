using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Seguro
    {
        private String numApolice;
        private String designacao;
        private String capitalObrigatorio;
        private String capitalFacultativo;
        private String nomeCompanhia;
        private String tipo;

        public override string ToString()
        {
            return codigo + " - " + designacao;
        }

        public String Codigo
        {
            get { return codigo; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O código de um serviço não pode ser null.");
                }
                codigo = value;
            }
        }

         public String Designacao
        {
            get { return designacao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A designação de um serviço não pode ser null.");
                }
                designacao = value;
            }
        }

        public String Custo
        {
            get { return custo; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O custo de um serviço não pode ser null.");
                }
                custo = value;
            }
        }
        public String Horas
        {
            get { return horas; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("As horas de um serviço não pode ser null.");
                }
                horas = value;
            }
        }       
    }
}
