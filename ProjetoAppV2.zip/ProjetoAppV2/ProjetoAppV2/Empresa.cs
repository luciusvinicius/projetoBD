using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Empresa: Entidade
    {
        private String _nipc;

        public Empresa(String i, String t, String n, String em, String end) : base(i, t, n, em, end)
        {
           
        }

        public String ToString() {
            return base.Nome;
        }
        public String NIPC
        {
            get { return _nipc; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O nipc não pode ser null.");
                    //return;
                }
                _nipc = value;
            }
        }
    }
}

