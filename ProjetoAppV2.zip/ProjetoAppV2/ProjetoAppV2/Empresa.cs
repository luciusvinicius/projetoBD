using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Empresa: Entidade
    {
        private String _nipc;
        private String _inicioExercicio;
        private String _fimExercicio;
        private String _fracao;
        public Empresa(String i, String t, String n, String em, String end) : base(i, t, n, em, end)
        {
           
        }

        public String ToString() {
            return base.Nome;
        }
        public String Fracao
        {
            get { return _fracao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A fração não pode ser null.");
                    //return;
                }
                _fracao = value;
            }
        }
        public String InicioExercicio
        {
            get { return _inicioExercicio; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O início de exercício não pode ser null.");
                }
                _inicioExercicio = value;
            }
        }

        public String FimExercicio
        {
            get { return _fimExercicio; }
            set { _fimExercicio = value; }
        }
        public String NIPC
        {
            get { return _nipc; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O nipc não pode ser null.");
                    //return;
                }
                _nipc = value;
            }
        }
    }
}

