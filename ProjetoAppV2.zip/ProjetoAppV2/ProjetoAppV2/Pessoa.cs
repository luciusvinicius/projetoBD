﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Pessoa: Entidade
    {
        private String _numContribuinte;
        private String _numCC;
        private String _genero;
        private String _dataNascimento;

        public Pessoa(String i, String t, String n, String em, String end) : base(i, t, n, em, end)
        {
           
        }

        public String toString() {
            return base.Nome;
        }
        public String NumContribuinte
        {
            get { return _numContribuinte; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O número de contribuinte não pode ser null.");
                    //return;
                }
                _numContribuinte = value;
            }
        }

        public String NumCC
        {
            get { return _numCC; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O número de CC não pode ser null.");
                    //return;
                }
                _numCC = value;
            }
        }

        public String Genero
        {
            get { return _genero; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O genero não pode ser null.");
                    //return;
                }
                _genero = value;
            }
        }

        public String DataNascimento
        {
            get { return _dataNascimento; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A data de nascimento não pode ser null.");
                    //return;
                }
                _dataNascimento = value;
            }
        }
    }
}

