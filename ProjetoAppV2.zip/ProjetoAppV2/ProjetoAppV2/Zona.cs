using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Zona
    {
        private String codigo;
        private String designacao;

        public override string ToString()
        {
            return codigo + " - " + designacao;
        }

        public String Codigo
        {
            get { return codigo; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O código de uma zona não pode ser null.");
                }
                codigo = value;
            }
        }

         public String Designacao
        {
            get { return designacao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("A designação de uma zona não pode ser null.");
                }
                designacao = value;
            }
        }
    }
}
