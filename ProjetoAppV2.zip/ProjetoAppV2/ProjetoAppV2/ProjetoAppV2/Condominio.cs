﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
	[Serializable()]
	public class Condominio
	{
		private String _numContribuinte;
		private String _numRegistro;
		private String _nome;
		private String _inicioExercicio;
		private String _fimExercicio;
		private String _estado;
		private String _saldo;
		private String _endereco;

        public override string ToString()
        {
            return _nome;
        }

        public String NumContribuinte
        {
            get { return _numContribuinte; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O numero de contribuinte não pode ser null.");
                }
                _numContribuinte = value; 
                }
        }

        public String NumRegistro
        {
            get { return _numRegistro; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O numero de registo não pode ser null.");
                }
                _numRegistro = value; 
                }
        }

        public String Nome
        {
            get { return _nome; }
            set
            {
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O nome do condominio não pode ser null.");
                }
                _nome = value;
            }
        }

        public String InicioExercicio
        {
            get { return _inicioExercicio; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O início de exercício não pode ser null.");
                }
                _inicioExercicio = value; 
                }
        }

        public String FimExercicio
        {
            get { return _fimExercicio; }
            set { _fimExercicio = value; }
        }

        public String Estado
        {
            get { return _estado; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O estado do condominio não pode ser null.");
                }
                _estado = value.Equals("True") ? "Ativo" : "Inativo"; 
                }
        }

        public String Saldo { 
            get { return _saldo; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O saldo do condomínio não pode ser null.");
                }
                _saldo = value; 
                }
        }

        public String Endereco
        {
            get { return _endereco; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O endereço do condominio não pode ser null.");
                }
                _endereco = value; 
                }
        }
    }
}

