using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public class Condomino
    {
        private String inicioExercicio;
        private String fimExercicio;
        private String identificadorEntidade;
        private String identificadorFracao;
        private String identificadorCondominio;

        /*public Condomino(String iExercicio, String fExercicio, String iEntidade, String iFracao, String iCondominio) {
            inicioExercicio = iExercicio;
            fimExercicio = fExercicio;
            identificadorEntidade = iEntidade;
            identificadorFracao = iFracao;
            identificadorCondominio = iCondominio;
        }*/
        public override string ToString()
        {
            return identificadorEntidade;
        }

        public String InicioExercicio
        {
            get { return inicioExercicio; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O início de exercício não pode ser null.");
                }
                inicioExercicio = value;
            }
        }

         public String FimExercicio
        {
            get { return fimExercicio; }
            set { fimExercicio = value; }
        }

        public String IdentificadorEntidade
        {
            get { return identificadorEntidade; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O identificador da entidade não pode ser null.");
                }
                identificadorEntidade = value;
            }
        }
        public String IdentificadorCondominio
        {
            get { return identificadorCondominio; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O identificador do condomínio não pode ser null.");
                }
                identificadorCondominio = value;
            }
        }
        public String IdentificadorFracao
        {
            get { return identificadorFracao; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O identificador da fração não pode ser null.");
                }
                identificadorFracao = value;
            }
        }        
    }
}
