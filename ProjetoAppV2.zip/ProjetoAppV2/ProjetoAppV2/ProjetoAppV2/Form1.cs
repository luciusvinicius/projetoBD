﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ProjetoClasse;
using System.Diagnostics;
using System.Collections;

namespace ProjetoAppV2
{
    public partial class Form1 : Form
    {
        private SqlConnection cn;
        private int currentCondominio;
        private String currentAtt;
        private String currentAdd;
        private String currentPagar;
        public Form1()
        {
            InitializeComponent();
            Console.WriteLine("print qualquer");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cn = getSGBDConnection();
            //loadCustomersToolStripMenuItem_Click(sender, e);
            loadCondominios();
        }

        private SqlConnection getSGBDConnection()
        {
            return new SqlConnection("data source= (LocalDb)\\MSSQLLocalDB;integrated security=true;initial catalog=projetoCondominio");
        }

        private bool verifySGBDConnection()
        {
            if (cn == null)
                cn = getSGBDConnection();

            if (cn.State != ConnectionState.Open)
                cn.Open();

            return cn.State == ConnectionState.Open;
        }

        private void condominioListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            attDropdown.Items.Clear();
            attListBox.Items.Clear();
            hideParameters();
            attDropdown.Show();
  
            if (condominioListBox.SelectedIndex >= 0)
            {
                currentCondominio = condominioListBox.SelectedIndex;
                ShowCondominio();

            }

            attDropdown.SelectedIndex = 0;

        }

        private void hideParameters() {
            removeButton.Hide();
            editButton.Hide();
            //fracaoArea.Visible = false;
            //fracaoAreaText.Visible = false;
            //fracaoEndereco.Visible = false;
            //fracaoEnderecoText.Visible = false;
            //fracaoIdentificador.Visible = false;
            //fracaoIdentificadorText.Visible = false;
            fracaoPainel.Hide();
            condominioPainel.Hide();
            ProprietarioEmpresa.Hide();
            ProprietarioPessoa.Hide();
            CondominoEmpresa.Hide();
            CondominoPessoa.Hide();
            Seguro.Hide();
            Servico.Hide();
            //secAttDropdown.Hide();
        }

        private void ShowCondominio()
        {
            if (condominioListBox.Items.Count == 0 | currentCondominio < 0) {
                return;
            }
                
            Condominio condominio = (Condominio)condominioListBox.Items[currentCondominio];

            attDropdown.Items.Add("Condomínio");
            attDropdown.Items.Add("Fração");
            attDropdown.Items.Add("Proprietários - Pessoas");
            attDropdown.Items.Add("Proprietários - Empresas");
            attDropdown.Items.Add("Condóminos - Pessoas");
            attDropdown.Items.Add("Condóminos - Empresas");
            attDropdown.Items.Add("Seguros");
            attDropdown.Items.Add("Serviços");

            condominioNome.Text = condominio.Nome;
            condominioEndereco.Text = condominio.Endereco;
            condominioEstado.Text = condominio.Estado;
            condominioInicio.Text = condominio.InicioExercicio;
            condominioFim.Text = condominio.FimExercicio;
            condominioNumContribuinte.Text = condominio.NumContribuinte;
            condominioNumRegistro.Text = condominio.NumRegistro;
            condominioSaldo.Text = condominio.Saldo;

        }

        private void attDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            String selection = (String) attDropdown.SelectedItem;

            // esconder todas as caixas de texto, para então mostrar a correta
            hideParameters();

            attListBox.Items.Clear();
            Condominio condominio = (Condominio) condominioListBox.SelectedItem;
            String numContribuinte = condominio.NumContribuinte;
            attListBox.Visible = true;
            attSearchBox.Show();

            switch (selection)
            {
                case "Condomínio":
                    condominioPainel.Show();
                    removeButton.Show();
                    editButton.Show();
                    attListBox.Visible = false;
                    attSearchBox.Hide();
                    currentAtt = "Condomínio";
                    break;
                case "Fração":
                    ShowFracoes(numContribuinte);
                    currentAtt = "Fração";
                    break;
                case "Proprietários - Pessoas":
                    showProprietariosPessoas(numContribuinte);
                    currentAtt = "Proprietários - Pessoas";
                    break;
                case "Condóminos - Pessoas":
                    showCondominosPessoas(numContribuinte);
                    currentAtt = "Condóminos - Pessoas";
                    break;
                case "Proprietários - Empresas":
                    showProprietariosEmpresas(numContribuinte);
                    currentAtt = "Proprietários - Empresas";
                    break;
                case "Condóminos - Empresas":
                    showCondominosEmpresas(numContribuinte);
                    currentAtt = "Condóminos - Empresas";
                    break;
                case "Seguros":
                    showSeguros(numContribuinte);
                    currentAtt = "Seguros";
                    break;
                case "Serviços":
                    showServicos(numContribuinte);
                    currentAtt = "Serviços";
                    break;
                default:
                    break;
            }
        }
        private void attListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            //secAttDropdown.Items.Clear();
            //secAttListBox.Items.Clear();
            if (attListBox.SelectedIndex < 0) return;
            removeButton.Show();
            editButton.Show();
            switch (currentAtt) {
                case "Fração":
                    //secAttDropdown.Show();
                    //secAttDropdown.Items.Add("Fração");
                    //secAttDropdown.Items.Add("Proprietários Pessoas");
                    //secAttDropdown.Items.Add("Proprietários Empresa");
                    //secAttDropdown.Items.Add("Condominos Pessoas");
                    //secAttDropdown.Items.Add("Condominos Empresa");
                    //secAttDropdown.SelectedIndex = 0;
                    Fracao F = (Fracao) attListBox.SelectedItem;
                    showFracao(F);
                    break;
                case "Proprietários - Pessoas":
                    Pessoa P = (Pessoa)attListBox.SelectedItem;
                    showProprietarioPessoa(P);
                    break;
                case "Condóminos - Pessoas":
                    Pessoa P2 = (Pessoa)attListBox.SelectedItem;
                    showCondominoPessoa(P2);
                    break;
                case "Proprietários - Empresas":
                    Empresa E = (Empresa)attListBox.SelectedItem;
                    showProprietarioEmpresa(E);
                    break;
                case "Condóminos - Empresas":
                    Empresa E2 = (Empresa)attListBox.SelectedItem;
                    showCondominoEmpresa(E2);
                    break;
                case "Seguros":
                    Seguro S = (Seguro)attListBox.SelectedItem;
                    showSeguro(S);
                    break;
                case "Serviços":
                    Servico S1 = (Servico)attListBox.SelectedItem;
                    showServico(S1);
                    break;
                default:
                    break;
              }
        }

        private void showFracao(Fracao F)
        {
            if (F == null) return;
            fracaoPainel.Show();
            fracaoIdentificador.Text = F.Identificador;
            fracaoArea.Text = F.Area;
            fracaoEndereco.Text = F.Localizacao;
        }
        private void showSeguro(Seguro S)
        {

            if (S == null) return;
            Seguro.Show();

            SeguroCapitalF.Text = S.CapitalFacultativo;
            SeguroCapitalO.Text = S.CapitalObrigatorio;
            SeguroDesignacao.Text = S.Designacao;
            SeguroFracao.Text = S.Fracao;
            SeguroNomeCompanhia.Text = S.NomeCompanhia;
            SeguroNumApolice.Text = S.NumApolice;
            SeguroTipo.Text = S.Tipo;
        }

        private void showServico(Servico S)
        {

            if (S == null) return;
            Servico.Show();

            ServicoCodigo.Text = S.Codigo;
            ServicoCusto.Text = S.Custo;
            ServicoDesignacao.Text = S.Designacao;
            ServicoHoras.Text = S.Horas;
        }
        private void showProprietarioPessoa(Pessoa Pe)
        {

            if (Pe == null) return;
            ProprietarioPessoa.Show();

            ProprietarioPessoaDataNascimento.Text = Pe.DataNascimento;
            ProprietarioPessoaEmail.Text = Pe.Email;
            ProprietarioPessoaEndereco.Text = Pe.EnderecoAtual;
            ProprietarioPessoaG.Text = Pe.Genero;
            ProprietarioPessoaID.Text = Pe.Identificador;
            ProprietarioPessoaNIF.Text = Pe.NumContribuinte;
            ProprietarioPessoaNumCC.Text = Pe.NumCC;
            ProprietarioPessoaNome.Text = Pe.Nome;
            ProprietarioPessoaTelemovel.Text = Pe.Telemovel;
            ProprietarioPessoaIE.Text = Pe.InicioExercicio;
            ProprietarioPessoaFE.Text = Pe.FimExercicio;
            ProprietarioPessoaFracao.Text = Pe.Fracao;
        }

        private void showCondominoPessoa(Pessoa Pe)
        {
            if (Pe == null) return;
            CondominoPessoa.Show();

            CondominoPessoaDataNasc.Text = Pe.DataNascimento;
            CondominoPessoaEmail.Text = Pe.Email;
            CondominoPessoaEndereco.Text = Pe.EnderecoAtual;
            CondominoPessoaG.Text = Pe.Genero;
            CondominoPessoaID.Text = Pe.Identificador;
            CondominoPessoaNIF.Text = Pe.NumContribuinte;
            CondominoPessoaNumCC.Text = Pe.NumCC;
            CondominoPessoaNome.Text = Pe.Nome;
            CondominoPessoaTelemovel.Text = Pe.Telemovel;
            CondominoPessoaIE.Text = Pe.InicioExercicio;
            CondominoPessoaFE.Text = Pe.FimExercicio;
            CondominoPessoaFracao.Text = Pe.Fracao;
        }

        private void showProprietarioEmpresa(Empresa E)
        {
            if (E == null) return;
            ProprietarioEmpresa.Show();

            ProprietarioEmpresaEmail.Text = E.Email;
            ProprietarioEmpresaEndereco.Text = E.EnderecoAtual;
            ProprietarioEmpresaID.Text = E.Identificador;
            ProprietarioEmpresaNIPC.Text = E.NIPC;
            ProprietarioEmpresaNome.Text = E.Nome;
            ProprietarioEmpresaTelemovel.Text = E.Telemovel;
            ProprietarioEmpresaIE.Text = E.InicioExercicio;
            ProprietarioEmpresaFE.Text = E.FimExercicio;
            ProprietarioEmpresaTelemovel.Text = E.Telemovel;
            ProprietarioEmpresaIE.Text = E.InicioExercicio;
            ProprietarioEmpresaFE.Text = E.FimExercicio;
            ProprietarioEmpresaFracao.Text = E.Fracao;
        }

        private void showCondominoEmpresa(Empresa E)
        {
            if (E == null) return;
            CondominoEmpresa.Show();

            CondominoEmpresaEmail.Text = E.Email;
            CondominoEmpresaEndereco.Text = E.EnderecoAtual;
            CondominoEmpresaID.Text = E.Identificador;
            CondominoEmpresaNIPC.Text = E.NIPC;
            CondominoEmpresaNome.Text = E.Nome;
            CondominoEmpresaTelemovel.Text = E.Telemovel;
            CondominoEmpresaIE.Text = E.InicioExercicio;
            CondominoEmpresaFE.Text = E.FimExercicio;
            CondominoEmpresaTelemovel.Text = E.Telemovel;
            CondominoEmpresaIE.Text = E.InicioExercicio;
            CondominoEmpresaFE.Text = E.FimExercicio;
            CondominoEmpresaFracao.Text = E.Fracao;
        }
    

        private void removeButton_Click(object sender, EventArgs e)
        {
            String message = "Tem certeza que deseja apagar da base de dados? (Não poderá refazer)";
            String title = "Remover";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);

            if (result == DialogResult.Yes)
            {
                Debug.WriteLine("Apagado >:(");
            }
 
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            attDropdown.Enabled = false;
            condominioListBox.Enabled = false;
            attListBox.Enabled = false;
        
            removeButton.Hide();
            editButton.Hide();
            saveButton.Show();
            cancelButton.Show();
            switch (currentAtt) {
                case "Condomínio":
                    editCondominio(true);
                    break;
                case "Fração":
                    editFracao(true);
                    break;
                default:
                    break;
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            String message = "Tem certeza que deseja atualizar?";
            String title = "Salvar";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);

            if (result == DialogResult.Yes)
            {
                Debug.WriteLine("Salvo :)");
                attDropdown.Enabled = true;
                condominioListBox.Enabled = true;
                attListBox.Enabled = true;
                removeButton.Show();
                editButton.Show();
                saveButton.Hide();
                cancelButton.Hide();
                switch (currentAtt)
                {
                    case "Condomínio":
                        updateCondominio();
                        editCondominio(false);
                        break;
                    case "Fração":
                        updateFracao();
                        editFracao(false);
                        break;
                    default:
                        break;
                }
            }
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            attDropdown.Items.Clear();
            ShowCondominio();
            attDropdown.Enabled = true;
            condominioListBox.Enabled = true;
            attListBox.Enabled = true;
            removeButton.Show();
            editButton.Show();
            saveButton.Hide();
            cancelButton.Hide();
            switch (currentAtt)
            {
                case "Condomínio":
                    editCondominio(false);
                    break;
                case "Fração":
                    editFracao(false);
                    break;
                default:
                    break;
            }
        }


        private void updateCondominio()
        {
            String nome = condominioNome.Text;
            String endereco = condominioEndereco.Text;
            String estado = condominioEstado.Text;
            String inicio = condominioInicio.Text;
            String fim = condominioFim.Text;
            String numCC = condominioNumContribuinte.Text;
            String numReg = condominioNumRegistro.Text;
            String saldo = condominioSaldo.Text;

            int numReg2 = 0;
            double saldo2 = 0;
            int estado2 = 0;

            if (estado.Equals("Ativo"))
            {
                estado2 = 1;
            }
            else
            {
                estado2 = 0;
            }
            try
            {
                numReg2 = Int32.Parse(numReg);
                saldo2 = Convert.ToDouble(saldo);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }

            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.updateCondominio", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@numContribuinte", numCC));
                cmd.Parameters.Add(new SqlParameter("@numRegistro", numReg2));
                cmd.Parameters.Add(new SqlParameter("@nome", nome));
                cmd.Parameters.Add(new SqlParameter("@inicioExercicio", inicio));
                cmd.Parameters.Add(new SqlParameter("@fimExercicio", fim));
                cmd.Parameters.Add(new SqlParameter("@estado", estado2));
                cmd.Parameters.Add(new SqlParameter("@saldo", saldo2));
                cmd.Parameters.Add(new SqlParameter("@endereco", endereco));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Condomínio Atualizado!", "Sucesso");

                loadCondominios();
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void updateFracao() {
            String ident = fracaoIdentificador.Text;
            String area = fracaoArea.Text;
            String endereco = fracaoEndereco.Text;

            int area2 = 0;
            try
            {
                area2 = Int32.Parse(area);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.updateFracao", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@identificador", ident));
                cmd.Parameters.Add(new SqlParameter("@area", area2));
                cmd.Parameters.Add(new SqlParameter("@localizacao", endereco));

                cmd.ExecuteNonQuery();
                MessageBox.Show("Fração Atualizada!", "Sucesso");

                Condominio condominio = (Condominio)condominioListBox.SelectedItem;
                String numContribuinte = condominio.NumContribuinte;

                attListBox.Items.Clear();
                ShowFracoes(numContribuinte);
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void editCondominio(bool value) {
            condominioEndereco.Enabled = value;
            condominioEstado.Enabled = value;
            condominioFim.Enabled = value;
            condominioInicio.Enabled = value;
            condominioNome.Enabled = value;
            //condominioNumContribuinte.Enabled = value;
            condominioNumRegistro.Enabled = value;
            condominioSaldo.Enabled = value;
        }

        private void editFracao(bool value)
        {
            fracaoArea.Enabled = value;
            fracaoEndereco.Enabled = value;
            //fracaoIdentificador.Enabled = value;
        }

        private void condominioSearch_TextChanged(object sender, EventArgs e)
        {
            loadCondominios();
        }

        private void attSearch_TextChanged(object sender, EventArgs e)
        {
            attListBox.Items.Clear();
            Condominio condominio = (Condominio)condominioListBox.SelectedItem;
            String numContribuinte = condominio.NumContribuinte;
            switch (currentAtt) {
                case "Fração":
                    ShowFracoes(numContribuinte);
                    break;
                case "Proprietários - Pessoas":
                    showProprietariosPessoas(numContribuinte);
                    break;
                case "Condóminos - Pessoas":
                    showCondominosPessoas(numContribuinte);
                    break;
                case "Proprietários - Empresas":
                    showProprietariosEmpresas(numContribuinte);
                    break;
                case "Condóminos - Empresas":
                    showCondominosEmpresas(numContribuinte);
                    break;
                case "Seguros":
                    showSeguros(numContribuinte);
                    break;
                case "Serviços":
                    showServicos(numContribuinte);
                    break;
                default:
                    break;
            }
        }

       

        //private void secAttDropdown_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    Condominio c = (Condominio)condominioListBox.SelectedItem;
        //    switch (currentAtt)
        //    {
        //        case "Fração":
        //            secAttListBox.Show();
        //            Fracao f = (Fracao)attListBox.SelectedItem;
        //            switch (secAttDropdown.SelectedItem) {
        //                case "Fração":
        //                    secAttListBox.Hide();
        //                    break;
        //                case "Proprietários Pessoas":
        //                    Debug.WriteLine("amogus");
        //                    //showProprietariosPessoas(c.NumContribuinte, f.Identificador, secAttSearch.Text, true);
        //                    break;

        //                default:
        //                    break;
        //            }
        //            break;

        //        default:
        //            break;
        //    }
        //}


        //---------------------------------------------------------------------------
        //-----------------------------------ADD-------------------------------------
        //---------------------------------------------------------------------------


        private void hideAdds()
        {
            addCondominio.Hide();
            addFracao.Hide();
            addPessoa.Hide();
            addEmpresa.Hide();
            addZona.Hide();
            addSeguro.Hide();
            addServico.Hide();
        }

        private void addType_SelectedIndexChanged(object sender, EventArgs e)
        {
            hideAdds();
            if (addType.SelectedIndex < 0) return;

            switch (addType.SelectedItem) {

                case "Condomínio":
                    addCondominio.Show();
                    currentAdd = "Condomínio";
                    break;

                case "Fração":
                    addFracao.Show();
                    currentAdd = "Fração";
                    break;
                case "Empresa":
                    addEmpresa.Show();
                    currentAdd = "Empresa";
                    break;
                case "Pessoa":
                    addPessoa.Show();
                    currentAdd = "Pessoa";
                    break;
                case "Seguro":
                    addSeguro.Show();
                    currentAdd = "Seguro";
                    break;
                case "Serviço":
                    addServico.Show();
                    currentAdd = "Serviço";
                    break;
                case "Zona":
                    addZona.Show();
                    currentAdd = "Zona";
                    break;
            }
        }


        private void addButton_Click(object sender, EventArgs e)
        {
            switch (currentAdd) {
                case "Condomínio":
                    addCondominioData();
                    break;
                case "Fração":
                    addFracaoData();
                    break;
                case "Empresa":
                    addEmpresaData();
                    break;
                case "Pessoa":
                    addPessoaData();
                    break;
                case "Serviço":
                    addServicoData();
                    break;
                case "Seguro":
                    addSeguroData();
                    break;
                case "Zona":
                    addZonaData();
                    break;
            }
        }

        private void addCondominioData()
        {
            String numC = addCondominioNumContribuinte.Text;
            String numReg = addCondominioNumRegistro.Text;
            String nome = addCondominioNome.Text;
            String inicio = addCondominioInicio.Text;
            String fim = addCondominioFim.Text;
            String estado = addCondominioEstado.Text;
            String saldo = addCondominioSaldo.Text;
            String endereco = addCondominioEndereco.Text;

            int numReg2 = 0;
            int estado2 = 0;
            double saldo2 = 0.0;

            if (estado.Equals("ativo")) {
                estado2 = 1;
            } else
            {
                estado2 = 0;
            }
            try
            {
                numReg2 = Int32.Parse(numReg);
                saldo2 = Convert.ToDouble(saldo);

            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }

            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertCondominio", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@numC", numC));
                cmd.Parameters.Add(new SqlParameter("@numReg", numReg2));
                cmd.Parameters.Add(new SqlParameter("@nome", nome));
                cmd.Parameters.Add(new SqlParameter("@inicio", inicio));
                cmd.Parameters.Add(new SqlParameter("@fim", fim));
                cmd.Parameters.Add(new SqlParameter("@estado", estado2));
                cmd.Parameters.Add(new SqlParameter("@saldo", saldo2));
                cmd.Parameters.Add(new SqlParameter("@endereco", endereco));

                cmd.ExecuteNonQuery();
                MessageBox.Show("Condomínio Inserido!", "Error");
                addCondominioNumContribuinte.Text = "";
                addCondominioNumRegistro.Text = "";
                addCondominioNome.Text = "";
                addCondominioInicio.Text = "";
                addCondominioFim.Text = "";
                addCondominioEstado.Text = "";
                addCondominioSaldo.Text = "";
                addCondominioEndereco.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }

        }

        private void addFracaoData()
        {
            String identificador = addFracaoIdentificador.Text;
            String area = addFracaoArea.Text;
            String localizacao = addFracaoLocalizacao.Text;
            String proprietario = addFracaoProprietario.Text;
            String condominio = addFracaoCondominio.Text;
            String zona = addFracaoZona.Text;

            int area2 = 0;
            int zona2 = 0;
            int proprietario2 = 0;

            try
            {
                area2 = Int32.Parse(area);
                zona2 = Int32.Parse(zona);
                proprietario2 = Int32.Parse(proprietario);

            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertFracao", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@identificador", identificador));
                cmd.Parameters.Add(new SqlParameter("@area", area2));
                cmd.Parameters.Add(new SqlParameter("@localizacao", localizacao));
                cmd.Parameters.Add(new SqlParameter("@entidade", proprietario2));
                cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
                cmd.Parameters.Add(new SqlParameter("@zona", zona2));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Fração adicionada!", "Success");
                addFracaoIdentificador.Text = "";
                addFracaoArea.Text = "";
                addFracaoLocalizacao.Text = "";
                addFracaoProprietario.Text = "";
                addFracaoCondominio.Text = "";
                addFracaoZona.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }
        private void addEmpresaData()
        {
            String identificador = addEmpresaIdentificador.Text;
            String nome = addEmpresaNome.Text;
            String telemovel = addEmpresaTelemovel.Text;
            String nipc = addEmpresaNIPC.Text;
            String email = addEmpresaEmail.Text;
            String endereco = addEmpresaEndereco.Text;

            int identificador2 = 0;

            try
            {
                identificador2 = Int32.Parse(identificador);

            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertEmpresa", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@identificador", identificador2));
                cmd.Parameters.Add(new SqlParameter("@nome", nome));
                cmd.Parameters.Add(new SqlParameter("@telemovel", telemovel));
                cmd.Parameters.Add(new SqlParameter("@nipc", nipc));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@endereco", endereco));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Empresa adicionada!", "Success");
                addEmpresaIdentificador.Text = "";
                addEmpresaNome.Text = "";
                addEmpresaTelemovel.Text = "";
                addEmpresaNIPC.Text = "";
                addEmpresaEmail.Text = "";
                addEmpresaEndereco.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void addPessoaData()
        {
            String identificador = addPessoaIdentificador.Text;
            String nome = addPessoaNome.Text;
            String telemovel = addPessoaTelemovel.Text;
            String nif = addPessoaNIF.Text;
            String email = addPessoaEmail.Text;
            String endereco = addPessoaEndereco.Text;
            String genero = addPessoaGenero.Text;
            String numCC = addPessoaNumCC.Text;
            String dataNascimento = addPessoaDataNascimento.Text;

            int identificador2 = 0;

            try
            {
                identificador2 = Int32.Parse(identificador);

            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertPessoa", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@identificador", identificador2));
                cmd.Parameters.Add(new SqlParameter("@nome", nome));
                cmd.Parameters.Add(new SqlParameter("@telemovel", telemovel));
                cmd.Parameters.Add(new SqlParameter("@numContribuinte", nif));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@endereco", endereco));
                cmd.Parameters.Add(new SqlParameter("@genero", genero));
                cmd.Parameters.Add(new SqlParameter("@numCC", numCC));
                cmd.Parameters.Add(new SqlParameter("@dataNascimento", dataNascimento));

                cmd.ExecuteNonQuery();

                addPessoaIdentificador.Text = "";
                addPessoaNome.Text = "";
                addPessoaTelemovel.Text = "";
                addPessoaNIF.Text = "";
                addPessoaEmail.Text = "";
                addPessoaEndereco.Text = "";
                addPessoaGenero.Text = "";
                addPessoaNumCC.Text = "";
                addPessoaDataNascimento.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void addSeguroData()
        {
            String numApolice = addSeguroNumApolice.Text;
            String tipo = addSeguroTipo.Text;
            String nomeCompanhia = addSeguroNome.Text;
            String capitalO = addSeguroCapitalO.Text;
            String capitalF = addSeguroCapitalF.Text;
            String designacao = addSeguroDesignacao.Text;
            String condominio = addSeguroCondominio.Text;
            String fracao = addSeguroFracao.Text;

            int numApolice2 = 0;
            double capitalO2 = 0;
            double capitalF2 = 0;

            try
            {
                numApolice2 = Int32.Parse(numApolice);
                capitalO2 = Convert.ToDouble(capitalO);
                if (!capitalF.Equals(""))
                    capitalF2 = Convert.ToDouble(capitalF);

            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }


            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertSeguro", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@numApolice", numApolice2));
                cmd.Parameters.Add(new SqlParameter("@tipo", tipo));
                cmd.Parameters.Add(new SqlParameter("@capitalO", capitalO2));
                if (capitalF.Equals(""))
                    cmd.Parameters.Add(new SqlParameter("@capitalF", null));
                else
                    cmd.Parameters.Add(new SqlParameter("@capitalF", capitalF2));
                cmd.Parameters.Add(new SqlParameter("@designacao", designacao));
                cmd.Parameters.Add(new SqlParameter("@nome", nomeCompanhia));
                cmd.Parameters.Add(new SqlParameter("@fracao", fracao));
                cmd.Parameters.Add(new SqlParameter("@condominio", condominio));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Seguro adicionado!", "Success");

                addSeguroNumApolice.Text = "";
                addSeguroTipo.Text = "";
                addSeguroNome.Text = "";
                addSeguroCapitalO.Text = "";
                addSeguroCapitalF.Text = "";
                addSeguroDesignacao.Text = "";
                addSeguroCondominio.Text = "";
                addSeguroFracao.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++) {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void addServicoData()
        {
            String codigo = addServicoCodigo.Text;
            String designacao = addServicoDesignacao.Text;
            String custo = addServicoCusto.Text;
            String horas = addServicoHoras.Text;
            String tipoPagamento = addServicoPagamento.Text;
            String condominio = addServicoCondominio.Text;

            double custo2 = 0;
            int horas2 = 0;
            int codigo2 = 0;

            try
            {
                codigo2 = Int32.Parse(codigo);
                custo2 = Convert.ToDouble(custo);
                horas2 = Int32.Parse(horas);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
            }

            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertServico", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@codigo", codigo2));
                cmd.Parameters.Add(new SqlParameter("@custo", custo2));
                cmd.Parameters.Add(new SqlParameter("@horas", horas2));
                cmd.Parameters.Add(new SqlParameter("@tipo", tipoPagamento));
                cmd.Parameters.Add(new SqlParameter("@designacao", designacao));
                cmd.Parameters.Add(new SqlParameter("@condominio", condominio));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Serviço adicionado!", "Success");
                addServicoCodigo.Text = "";
                addServicoDesignacao.Text = "";
                addServicoCusto.Text = "";
                addServicoHoras.Text = "";
                addServicoPagamento.Text = "";
                addServicoCondominio.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }

        private void addZonaData()
        {
            String codigo = addZonaCodigo.Text;
            String designacao = addZonaDesignacao.Text;

            int codigo2 = 0;

            try
            {
                codigo2 = Int32.Parse(codigo);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.insertZona", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@codigo", codigo2));
                cmd.Parameters.Add(new SqlParameter("@designacao", designacao));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Zona adicionado!", "Success");
                addZonaCodigo.Text = "";
                addZonaDesignacao.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }



        //---------------------------------------------------------------------------
        //-------------------------------QUERIES-------------------------------------
        //---------------------------------------------------------------------------

        private void loadCondominios()
        {
            condominioListBox.Items.Clear();
            if (!verifySGBDConnection()) return;

            String query = "SELECT * FROM gestaoCondominio.condominio WHERE @nome = '' OR nome LIKE '%'+@nome+'%'";

            SqlCommand cmd = new SqlCommand(query, cn);
            cmd.Parameters.Add("@nome", SqlDbType.NChar);
            cmd.Parameters["@nome"].Value = condominioSearch.Text;
            SqlDataReader reader = cmd.ExecuteReader();
            condominioListBox.Items.Clear();

            while (reader.Read())
            {
                Condominio C = new Condominio();
                C.Nome = reader["nome"].ToString();
                C.NumContribuinte = reader["numContribuinte"].ToString();
                C.NumRegistro = reader["numRegistro"].ToString();
                C.InicioExercicio = reader["inicioExercicio"].ToString();
                C.FimExercicio = reader["fimExercicio"].ToString();
                C.Estado = reader["estado"].ToString();
                C.Saldo = reader["saldo"].ToString();
                C.Endereco = reader["endereço"].ToString();
                condominioListBox.Items.Add(C);
            }
            reader.Close();
        }
        private void ShowFracoes(String numContribuinte)
        {
            if (!verifySGBDConnection()) return;

            SqlCommand cmd = new SqlCommand("gestaoCondominio.getFracoes", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", numContribuinte));
            cmd.Parameters.Add(new SqlParameter("@fracao", attSearchBox.Text));
            SqlDataReader reader = cmd.ExecuteReader();
            Debug.WriteLine(attSearchBox.Text);
            Debug.WriteLine(numContribuinte);
            while (reader.Read())
            {
                Fracao F = new Fracao();
                F.Identificador = reader["identificador"].ToString();
                F.Area = reader["area"].ToString();
                F.Localizacao = reader["localizacao"].ToString();
                attListBox.Items.Add(F);
            }

            reader.Close();
        }
        private void showProprietariosPessoas(String condominio)
        {
            if (!verifySGBDConnection()) return;

            SqlCommand cmd = new SqlCommand("gestaoCondominio.ProprietariosPessoas", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@nome", attSearchBox.Text));
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                String id = reader["identificador"].ToString();
                String telemovel = reader["telemovel"].ToString();
                String nome = reader["nome"].ToString();
                String endereco = reader["enderecoAtual"].ToString();
                String email = reader["email"].ToString();
                Pessoa P = new Pessoa(id, telemovel, nome, email, endereco);
                P.NumCC = reader["numCC"].ToString();
                P.NumContribuinte = reader["numContribuinte"].ToString();
                P.DataNascimento = reader["dataNascimento"].ToString();
                P.Genero = reader["genero"].ToString();
                P.InicioExercicio = reader["inicioExercicio"].ToString();
                P.FimExercicio = reader["fimExercicio"].ToString();
                P.Fracao = reader["FK_Fracao"].ToString(); 
                attListBox.Items.Add(P);
            }

            reader.Close();

        }
        private void showCondominosPessoas(String condominio)
        {
            if (!verifySGBDConnection()) return;

            SqlCommand cmd = new SqlCommand("gestaoCondominio.CondominosPessoas", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@nome", attSearchBox.Text));
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                String id = reader["identificador"].ToString();
                String telemovel = reader["telemovel"].ToString();
                String nome = reader["nome"].ToString();
                String endereco = reader["enderecoAtual"].ToString();
                String email = reader["email"].ToString();
                Pessoa P = new Pessoa(id, telemovel, nome, email, endereco);
                P.NumCC = reader["numCC"].ToString();
                P.NumContribuinte = reader["numContribuinte"].ToString();
                P.DataNascimento = reader["dataNascimento"].ToString();
                P.Genero = reader["genero"].ToString();
                P.InicioExercicio = reader["inicioExercicio"].ToString();
                P.FimExercicio = reader["fimExercicio"].ToString();
                P.Fracao = reader["FK_Fracao"].ToString();
                attListBox.Items.Add(P);
            }

            reader.Close();

        }
        private void showProprietariosEmpresas(String condominio)
        {
            if (!verifySGBDConnection()) return;

            SqlCommand cmd = new SqlCommand("gestaoCondominio.ProprietariosEmpresas", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@nome", attSearchBox.Text));
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                String id = reader["identificador"].ToString();
                String telemovel = reader["telemovel"].ToString();
                String nome = reader["nome"].ToString();
                String endereco = reader["enderecoAtual"].ToString();
                String email = reader["email"].ToString();
                Empresa P = new Empresa(id, telemovel, nome, email, endereco);
                P.NIPC = reader["nipc"].ToString();
                P.InicioExercicio = reader["inicioExercicio"].ToString();
                P.FimExercicio = reader["fimExercicio"].ToString();
                P.Fracao = reader["FK_Fracao"].ToString();
                attListBox.Items.Add(P);
                
            }

            reader.Close();

        }
        private void showCondominosEmpresas(String condominio)
        {
            if (!verifySGBDConnection()) return;

            SqlCommand cmd = new SqlCommand("gestaoCondominio.CondominosEmpresas", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@nome", attSearchBox.Text));
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                String id = reader["identificador"].ToString();
                String telemovel = reader["telemovel"].ToString();
                String nome = reader["nome"].ToString();
                String endereco = reader["enderecoAtual"].ToString();
                String email = reader["email"].ToString();
                Empresa P = new Empresa(id, telemovel, nome, email, endereco);
                P.NIPC = reader["nipc"].ToString();
                P.InicioExercicio = reader["inicioExercicio"].ToString();
                P.FimExercicio = reader["fimExercicio"].ToString();
                P.Fracao = reader["FK_Fracao"].ToString();
                attListBox.Items.Add(P);
            }

            reader.Close();

        }

        private void showServicos(String condominio)
        {
            SqlCommand cmd = new SqlCommand("gestaoCondominio.getServicos", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@servico", attSearchBox.Text));

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Servico S = new Servico();
                S.Custo = reader["custo"].ToString();
                S.Designacao = reader["designacao"].ToString();
                S.Horas = reader["horas"].ToString();
                S.Codigo = reader["codigo"].ToString();
                attListBox.Items.Add(S);
            }

            reader.Close();
        }
            private void showSeguros(String condominio)
        {
            SqlCommand cmd = new SqlCommand("gestaoCondominio.getSeguros", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
            cmd.Parameters.Add(new SqlParameter("@seguro", condominio));
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Seguro S = new Seguro();
                S.NumApolice = reader["numApolice"].ToString();
                S.Designacao = reader["designacao"].ToString();
                S.CapitalObrigatorio = reader["capitalObrigatorio"].ToString();
                S.CapitalFacultativo = reader["capitalFacultativo"].ToString();
                S.NomeCompanhia = reader["nomeCompanhanhia"].ToString();
                S.Tipo = reader["tipo"].ToString();
                S.Fracao = reader["FK_Fracao"].ToString();
                attListBox.Items.Add(S);
            }

            reader.Close();
        }




        //-------------------------------------------------------------METODOS------------------------------------------------------

        private void hideMethods()
        {
            methodPagarMensalidade.Hide();
            methodPagarServico.Hide();
            pagarButao.Hide();
        }

        private void dropdownMethods_SelectedIndexChanged(object sender, EventArgs e)
        {
            hideMethods();
            if (dropdownMethods.SelectedIndex < 0) return;

            switch (dropdownMethods.SelectedItem)
            {
                case "Pagar Mensalidade":
                    Debug.WriteLine("clicou");
                    methodPagarMensalidade.Show();
                    pagarButao.Show();
                    currentPagar = "Pagar Mensalidade";
                    break;
                case "Pagar Serviço":
                    methodPagarServico.Show();
                    pagarButao.Show();
                    currentPagar = "Pagar Serviço";
                    break;
            }
        }

        private void pagarBotao_Click(object sender, EventArgs e)
        {
            switch (currentPagar)
            {
                case "Pagar Mensalidade":
                    pagaMensalidade(methodPagarMensalidadeAno.Text, methodPagarMensalidadeEntidade.Text, methodPagarMensalidadeCondominio.Text, methodPagarMensalidadeFracao.Text, methodPagarMensalidadeValor.Text, methodPagarMensalidadeTipo.Text);
                    break;
                case "Pagar Serviço":
                    pagaServico(methodPagarServicoCodigo.Text, methodPagarServicoTipo.Text);
                    break;
            }
        }
        
        private void pagaMensalidade(String ano, String entidade, String condominio, String fracao, String valor, String tipo)
        {
            Debug.WriteLine("qualquer coisa");
            int ano2 = 0;
            double valor2 = 0.0;
            int entidade2 = 0;
            Debug.WriteLine(valor);
            try
            {
                ano2 = Int32.Parse(ano);
                valor2 = double.Parse(valor);
                entidade2 = Int32.Parse(entidade);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.pagaMensalidade", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@condominio", condominio));
                cmd.Parameters.Add(new SqlParameter("@ano", ano2));
                cmd.Parameters.Add(new SqlParameter("@entidade", entidade2));
                cmd.Parameters.Add(new SqlParameter("@fracao", fracao));
                cmd.Parameters.Add(new SqlParameter("@valor", valor2));
                cmd.Parameters.Add(new SqlParameter("@tipo", tipo));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Mensalidade paga!", "Success");
                methodPagarMensalidadeValor.Text = "";
                methodPagarMensalidadeTipo.Text = "";
                methodPagarMensalidadeFracao.Text = "";
                methodPagarMensalidadeCondominio.Text = "";
                methodPagarMensalidadeEntidade.Text = "";
                methodPagarMensalidadeAno.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }
        private void pagaServico(String codigo, String tipo)
        {
            int codigo2 = 0;
            try
            {
                codigo2 = Int32.Parse(codigo);
            }
            catch
            {
                MessageBox.Show("Invalid numbers!", "Error");
                return;
            }
            try
            {
                SqlCommand cmd = new SqlCommand("gestaoCondominio.pagaServico", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@codigo", codigo2));
                cmd.Parameters.Add(new SqlParameter("@tipo", tipo));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Serviço paga!", "Success");
                methodPagarServicoCodigo.Text = "";
                methodPagarServicoTipo.Text = "";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    MessageBox.Show(ex.Errors[i].Message, "Error");
                }
            }
        }
        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void addEmpresaTelemovel_TextChanged(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void addEmpresaEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        //private void secAttListBox_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //}

        private void label62_Click(object sender, EventArgs e)
        {

        }

        private void label56_Click(object sender, EventArgs e)
        {

        }

        private void label93_Click(object sender, EventArgs e)
        {

        }

        private void label109_Click(object sender, EventArgs e)
        {

        }

        private void attSearchBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
