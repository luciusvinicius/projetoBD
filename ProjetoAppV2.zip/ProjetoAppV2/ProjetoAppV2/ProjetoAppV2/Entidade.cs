﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace ProjetoClasse
{
    [Serializable()]
    public abstract class Entidade
    {
        private String _identificador;
        private String _telemovel;
        private String _nome;
        private String _email;
        private String _enderecoAtual;

        public Entidade(String i, String t, String n, String em, String end) {
            _identificador = i;
            _telemovel = t;
            _nome = n;
            _email = em;
            _enderecoAtual = end;
        }
        public override string ToString()
        {
            return _nome;
        }

        public String Identificador
        {
            get { return _identificador; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O identificador da entidade não pode ser null.");
                }
                _identificador = value;
            }
        }

        public String Nome
        {
            get { return _nome; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O nome da entidade não pode ser null.");
                    //return;
                }
                _nome = value;
            }
        }

        public String Email
        {
            get { return _email; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O email de uma entidade não pode ser null.");
                }
                _email = value; 
                }
        }

        public String EnderecoAtual
        {
            get { return _enderecoAtual; }
            set
            {
                if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O endereço atual da entidade não pode ser null");
                    //return;
                }
                _enderecoAtual = value;
            }
        }

        public String Telemovel
        {
            get { return _telemovel; }
            set { 
                 if (value == null | String.IsNullOrEmpty(value))
                {
                    throw new Exception("O telemóvel da entidade não pode ser null.");
                }
                _telemovel = value;
            }
        }
    }
}

