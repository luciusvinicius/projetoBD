﻿
namespace ProjetoAppV2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewAdd = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.secAttSearch = new System.Windows.Forms.TextBox();
            this.secAttDropdown = new System.Windows.Forms.ComboBox();
            this.secAttListBox = new System.Windows.Forms.ListBox();
            this.condominioSearch = new System.Windows.Forms.TextBox();
            this.attSearch = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.attDropdown = new System.Windows.Forms.ComboBox();
            this.attListBox = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.condominioListBox = new System.Windows.Forms.ListBox();
            this.fracaoPainel = new System.Windows.Forms.Panel();
            this.fracaoEndereco = new System.Windows.Forms.TextBox();
            this.fracaoEnderecoText = new System.Windows.Forms.Label();
            this.fracaoArea = new System.Windows.Forms.TextBox();
            this.fracaoAreaText = new System.Windows.Forms.Label();
            this.fracaoIdentificador = new System.Windows.Forms.TextBox();
            this.fracaoIdentificadorText = new System.Windows.Forms.Label();
            this.condominioPainel = new System.Windows.Forms.Panel();
            this.condominioEndereco = new System.Windows.Forms.TextBox();
            this.condominioSaldo = new System.Windows.Forms.TextBox();
            this.condominioFim = new System.Windows.Forms.TextBox();
            this.condominioInicio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.condominioNome = new System.Windows.Forms.TextBox();
            this.condominioEstado = new System.Windows.Forms.TextBox();
            this.condominioNumRegistro = new System.Windows.Forms.TextBox();
            this.condominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.addButton = new System.Windows.Forms.Button();
            this.addCondominio = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.addCondominioEstado = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.addCondominioInicio = new System.Windows.Forms.TextBox();
            this.addCondominioFim = new System.Windows.Forms.TextBox();
            this.addCondominioNome = new System.Windows.Forms.TextBox();
            this.addCondominioSaldo = new System.Windows.Forms.TextBox();
            this.addCondominioEndereco = new System.Windows.Forms.TextBox();
            this.addCondominioNumRegistro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.addCondominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.addType = new System.Windows.Forms.ComboBox();
            this.viewAdd.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.fracaoPainel.SuspendLayout();
            this.condominioPainel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.addCondominio.SuspendLayout();
            this.SuspendLayout();
            // 
            // viewAdd
            // 
            this.viewAdd.Controls.Add(this.tabPage1);
            this.viewAdd.Controls.Add(this.tabPage2);
            this.viewAdd.Location = new System.Drawing.Point(12, 12);
            this.viewAdd.Name = "viewAdd";
            this.viewAdd.SelectedIndex = 0;
            this.viewAdd.Size = new System.Drawing.Size(776, 426);
            this.viewAdd.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.secAttSearch);
            this.tabPage1.Controls.Add(this.secAttDropdown);
            this.tabPage1.Controls.Add(this.secAttListBox);
            this.tabPage1.Controls.Add(this.condominioSearch);
            this.tabPage1.Controls.Add(this.attSearch);
            this.tabPage1.Controls.Add(this.cancelButton);
            this.tabPage1.Controls.Add(this.saveButton);
            this.tabPage1.Controls.Add(this.editButton);
            this.tabPage1.Controls.Add(this.removeButton);
            this.tabPage1.Controls.Add(this.attDropdown);
            this.tabPage1.Controls.Add(this.attListBox);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.condominioListBox);
            this.tabPage1.Controls.Add(this.fracaoPainel);
            this.tabPage1.Controls.Add(this.condominioPainel);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 398);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // secAttSearch
            // 
            this.secAttSearch.Location = new System.Drawing.Point(338, 33);
            this.secAttSearch.Name = "secAttSearch";
            this.secAttSearch.PlaceholderText = "Pesquisa";
            this.secAttSearch.Size = new System.Drawing.Size(100, 23);
            this.secAttSearch.TabIndex = 34;
            this.secAttSearch.Visible = false;
            // 
            // secAttDropdown
            // 
            this.secAttDropdown.FormattingEnabled = true;
            this.secAttDropdown.Location = new System.Drawing.Point(338, 3);
            this.secAttDropdown.Name = "secAttDropdown";
            this.secAttDropdown.Size = new System.Drawing.Size(121, 23);
            this.secAttDropdown.TabIndex = 33;
            this.secAttDropdown.Text = "Atributos";
            this.secAttDropdown.Visible = false;
            this.secAttDropdown.SelectedIndexChanged += new System.EventHandler(this.secAttDropdown_SelectedIndexChanged);
            // 
            // secAttListBox
            // 
            this.secAttListBox.FormattingEnabled = true;
            this.secAttListBox.ItemHeight = 15;
            this.secAttListBox.Location = new System.Drawing.Point(338, 63);
            this.secAttListBox.Name = "secAttListBox";
            this.secAttListBox.Size = new System.Drawing.Size(121, 319);
            this.secAttListBox.TabIndex = 32;
            this.secAttListBox.Visible = false;
            // 
            // condominioSearch
            // 
            this.condominioSearch.Location = new System.Drawing.Point(3, 2);
            this.condominioSearch.Name = "condominioSearch";
            this.condominioSearch.PlaceholderText = "Pesquisa";
            this.condominioSearch.Size = new System.Drawing.Size(100, 23);
            this.condominioSearch.TabIndex = 31;
            this.condominioSearch.TextChanged += new System.EventHandler(this.condominioSearch_TextChanged);
            // 
            // attSearch
            // 
            this.attSearch.Location = new System.Drawing.Point(211, 33);
            this.attSearch.Name = "attSearch";
            this.attSearch.PlaceholderText = "Pesquisa";
            this.attSearch.Size = new System.Drawing.Size(100, 23);
            this.attSearch.TabIndex = 26;
            this.attSearch.Visible = false;
            this.attSearch.TextChanged += new System.EventHandler(this.attSearch_TextChanged);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(583, 359);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 29;
            this.cancelButton.Text = "Cancelar";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Visible = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(675, 359);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 28;
            this.saveButton.Text = "Salvar";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Visible = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(675, 359);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(75, 23);
            this.editButton.TabIndex = 27;
            this.editButton.Text = "Editar";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Visible = false;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(583, 359);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(75, 23);
            this.removeButton.TabIndex = 20;
            this.removeButton.Text = "Remover";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Visible = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // attDropdown
            // 
            this.attDropdown.FormattingEnabled = true;
            this.attDropdown.Location = new System.Drawing.Point(211, 3);
            this.attDropdown.Name = "attDropdown";
            this.attDropdown.Size = new System.Drawing.Size(121, 23);
            this.attDropdown.TabIndex = 11;
            this.attDropdown.Text = "Atributos";
            this.attDropdown.SelectedIndexChanged += new System.EventHandler(this.attDropdown_SelectedIndexChanged);
            // 
            // attListBox
            // 
            this.attListBox.FormattingEnabled = true;
            this.attListBox.ItemHeight = 15;
            this.attListBox.Location = new System.Drawing.Point(211, 63);
            this.attListBox.Name = "attListBox";
            this.attListBox.Size = new System.Drawing.Size(121, 319);
            this.attListBox.TabIndex = 12;
            this.attListBox.Visible = false;
            this.attListBox.SelectedIndexChanged += new System.EventHandler(this.attListBox_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(704, 409);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 10);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // condominioListBox
            // 
            this.condominioListBox.FormattingEnabled = true;
            this.condominioListBox.ItemHeight = 15;
            this.condominioListBox.Location = new System.Drawing.Point(3, 33);
            this.condominioListBox.Name = "condominioListBox";
            this.condominioListBox.Size = new System.Drawing.Size(182, 349);
            this.condominioListBox.TabIndex = 10;
            this.condominioListBox.SelectedIndexChanged += new System.EventHandler(this.condominioListBox_SelectedIndexChanged);
            // 
            // fracaoPainel
            // 
            this.fracaoPainel.Controls.Add(this.fracaoEndereco);
            this.fracaoPainel.Controls.Add(this.fracaoEnderecoText);
            this.fracaoPainel.Controls.Add(this.fracaoArea);
            this.fracaoPainel.Controls.Add(this.fracaoAreaText);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificador);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificadorText);
            this.fracaoPainel.Location = new System.Drawing.Point(465, 3);
            this.fracaoPainel.Name = "fracaoPainel";
            this.fracaoPainel.Size = new System.Drawing.Size(300, 350);
            this.fracaoPainel.TabIndex = 21;
            this.fracaoPainel.Visible = false;
            // 
            // fracaoEndereco
            // 
            this.fracaoEndereco.Enabled = false;
            this.fracaoEndereco.Location = new System.Drawing.Point(21, 141);
            this.fracaoEndereco.Multiline = true;
            this.fracaoEndereco.Name = "fracaoEndereco";
            this.fracaoEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.fracaoEndereco.Size = new System.Drawing.Size(277, 183);
            this.fracaoEndereco.TabIndex = 25;
            // 
            // fracaoEnderecoText
            // 
            this.fracaoEnderecoText.AutoSize = true;
            this.fracaoEnderecoText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoEnderecoText.Location = new System.Drawing.Point(21, 105);
            this.fracaoEnderecoText.Name = "fracaoEnderecoText";
            this.fracaoEnderecoText.Size = new System.Drawing.Size(56, 15);
            this.fracaoEnderecoText.TabIndex = 24;
            this.fracaoEnderecoText.Text = "Endereço";
            // 
            // fracaoArea
            // 
            this.fracaoArea.Enabled = false;
            this.fracaoArea.Location = new System.Drawing.Point(162, 59);
            this.fracaoArea.Name = "fracaoArea";
            this.fracaoArea.Size = new System.Drawing.Size(76, 23);
            this.fracaoArea.TabIndex = 23;
            // 
            // fracaoAreaText
            // 
            this.fracaoAreaText.AutoSize = true;
            this.fracaoAreaText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoAreaText.Location = new System.Drawing.Point(162, 30);
            this.fracaoAreaText.Name = "fracaoAreaText";
            this.fracaoAreaText.Size = new System.Drawing.Size(57, 15);
            this.fracaoAreaText.TabIndex = 22;
            this.fracaoAreaText.Text = "Area (m²)";
            // 
            // fracaoIdentificador
            // 
            this.fracaoIdentificador.Enabled = false;
            this.fracaoIdentificador.Location = new System.Drawing.Point(21, 59);
            this.fracaoIdentificador.Name = "fracaoIdentificador";
            this.fracaoIdentificador.Size = new System.Drawing.Size(100, 23);
            this.fracaoIdentificador.TabIndex = 20;
            // 
            // fracaoIdentificadorText
            // 
            this.fracaoIdentificadorText.AutoSize = true;
            this.fracaoIdentificadorText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoIdentificadorText.Location = new System.Drawing.Point(21, 30);
            this.fracaoIdentificadorText.Name = "fracaoIdentificadorText";
            this.fracaoIdentificadorText.Size = new System.Drawing.Size(74, 15);
            this.fracaoIdentificadorText.TabIndex = 21;
            this.fracaoIdentificadorText.Text = "Identificador";
            // 
            // condominioPainel
            // 
            this.condominioPainel.Controls.Add(this.condominioEndereco);
            this.condominioPainel.Controls.Add(this.condominioSaldo);
            this.condominioPainel.Controls.Add(this.condominioFim);
            this.condominioPainel.Controls.Add(this.condominioInicio);
            this.condominioPainel.Controls.Add(this.label8);
            this.condominioPainel.Controls.Add(this.label7);
            this.condominioPainel.Controls.Add(this.label6);
            this.condominioPainel.Controls.Add(this.condominioNome);
            this.condominioPainel.Controls.Add(this.condominioEstado);
            this.condominioPainel.Controls.Add(this.condominioNumRegistro);
            this.condominioPainel.Controls.Add(this.condominioNumContribuinte);
            this.condominioPainel.Controls.Add(this.label5);
            this.condominioPainel.Controls.Add(this.label4);
            this.condominioPainel.Controls.Add(this.label3);
            this.condominioPainel.Controls.Add(this.label2);
            this.condominioPainel.Controls.Add(this.label1);
            this.condominioPainel.Location = new System.Drawing.Point(211, 63);
            this.condominioPainel.Name = "condominioPainel";
            this.condominioPainel.Size = new System.Drawing.Size(554, 290);
            this.condominioPainel.TabIndex = 26;
            this.condominioPainel.Visible = false;
            // 
            // condominioEndereco
            // 
            this.condominioEndereco.Enabled = false;
            this.condominioEndereco.Location = new System.Drawing.Point(0, 186);
            this.condominioEndereco.Multiline = true;
            this.condominioEndereco.Name = "condominioEndereco";
            this.condominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.condominioEndereco.Size = new System.Drawing.Size(539, 89);
            this.condominioEndereco.TabIndex = 15;
            // 
            // condominioSaldo
            // 
            this.condominioSaldo.Enabled = false;
            this.condominioSaldo.Location = new System.Drawing.Point(404, 105);
            this.condominioSaldo.Name = "condominioSaldo";
            this.condominioSaldo.Size = new System.Drawing.Size(135, 23);
            this.condominioSaldo.TabIndex = 14;
            // 
            // condominioFim
            // 
            this.condominioFim.Enabled = false;
            this.condominioFim.Location = new System.Drawing.Point(427, 29);
            this.condominioFim.Name = "condominioFim";
            this.condominioFim.Size = new System.Drawing.Size(112, 23);
            this.condominioFim.TabIndex = 13;
            // 
            // condominioInicio
            // 
            this.condominioInicio.Enabled = false;
            this.condominioInicio.Location = new System.Drawing.Point(297, 30);
            this.condominioInicio.Name = "condominioInicio";
            this.condominioInicio.Size = new System.Drawing.Size(112, 23);
            this.condominioInicio.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(404, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Saldo (€)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(427, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Fim Exercício";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(297, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Início Exercício";
            // 
            // condominioNome
            // 
            this.condominioNome.Enabled = false;
            this.condominioNome.Location = new System.Drawing.Point(0, 105);
            this.condominioNome.Name = "condominioNome";
            this.condominioNome.Size = new System.Drawing.Size(383, 23);
            this.condominioNome.TabIndex = 8;
            // 
            // condominioEstado
            // 
            this.condominioEstado.Enabled = false;
            this.condominioEstado.Location = new System.Drawing.Point(213, 30);
            this.condominioEstado.Name = "condominioEstado";
            this.condominioEstado.Size = new System.Drawing.Size(67, 23);
            this.condominioEstado.TabIndex = 7;
            // 
            // condominioNumRegistro
            // 
            this.condominioNumRegistro.Enabled = false;
            this.condominioNumRegistro.Location = new System.Drawing.Point(141, 30);
            this.condominioNumRegistro.Name = "condominioNumRegistro";
            this.condominioNumRegistro.Size = new System.Drawing.Size(55, 23);
            this.condominioNumRegistro.TabIndex = 6;
            // 
            // condominioNumContribuinte
            // 
            this.condominioNumContribuinte.Enabled = false;
            this.condominioNumContribuinte.Location = new System.Drawing.Point(0, 30);
            this.condominioNumContribuinte.Name = "condominioNumContribuinte";
            this.condominioNumContribuinte.Size = new System.Drawing.Size(121, 23);
            this.condominioNumContribuinte.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Estado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Endereço";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número Contribuinte";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.addButton);
            this.tabPage2.Controls.Add(this.addCondominio);
            this.tabPage2.Controls.Add(this.addType);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 398);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(690, 368);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 2;
            this.addButton.Text = "Adicionar";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // addCondominio
            // 
            this.addCondominio.Controls.Add(this.label16);
            this.addCondominio.Controls.Add(this.label15);
            this.addCondominio.Controls.Add(this.addCondominioEstado);
            this.addCondominio.Controls.Add(this.label14);
            this.addCondominio.Controls.Add(this.label13);
            this.addCondominio.Controls.Add(this.label12);
            this.addCondominio.Controls.Add(this.label11);
            this.addCondominio.Controls.Add(this.addCondominioInicio);
            this.addCondominio.Controls.Add(this.addCondominioFim);
            this.addCondominio.Controls.Add(this.addCondominioNome);
            this.addCondominio.Controls.Add(this.addCondominioSaldo);
            this.addCondominio.Controls.Add(this.addCondominioEndereco);
            this.addCondominio.Controls.Add(this.addCondominioNumRegistro);
            this.addCondominio.Controls.Add(this.label10);
            this.addCondominio.Controls.Add(this.addCondominioNumContribuinte);
            this.addCondominio.Controls.Add(this.label9);
            this.addCondominio.Location = new System.Drawing.Point(3, 42);
            this.addCondominio.Name = "addCondominio";
            this.addCondominio.Size = new System.Drawing.Size(765, 320);
            this.addCondominio.TabIndex = 1;
            this.addCondominio.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 165);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 15);
            this.label16.TabIndex = 16;
            this.label16.Text = "Endereço";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(452, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 15);
            this.label15.TabIndex = 15;
            this.label15.Text = "Saldo";
            // 
            // addCondominioEstado
            // 
            this.addCondominioEstado.FormattingEnabled = true;
            this.addCondominioEstado.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.addCondominioEstado.Location = new System.Drawing.Point(607, 28);
            this.addCondominioEstado.Name = "addCondominioEstado";
            this.addCondominioEstado.Size = new System.Drawing.Size(97, 23);
            this.addCondominioEstado.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(607, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 15);
            this.label14.TabIndex = 13;
            this.label14.Text = "Estado";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(452, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 15);
            this.label13.TabIndex = 12;
            this.label13.Text = "Fim do Exercício";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(0, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 15);
            this.label12.TabIndex = 11;
            this.label12.Text = "Nome";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(300, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "Inicio do Exercício";
            // 
            // addCondominioInicio
            // 
            this.addCondominioInicio.Location = new System.Drawing.Point(300, 28);
            this.addCondominioInicio.Name = "addCondominioInicio";
            this.addCondominioInicio.Size = new System.Drawing.Size(121, 23);
            this.addCondominioInicio.TabIndex = 9;
            // 
            // addCondominioFim
            // 
            this.addCondominioFim.Location = new System.Drawing.Point(452, 28);
            this.addCondominioFim.Name = "addCondominioFim";
            this.addCondominioFim.Size = new System.Drawing.Size(121, 23);
            this.addCondominioFim.TabIndex = 8;
            // 
            // addCondominioNome
            // 
            this.addCondominioNome.Location = new System.Drawing.Point(0, 115);
            this.addCondominioNome.Name = "addCondominioNome";
            this.addCondominioNome.Size = new System.Drawing.Size(421, 23);
            this.addCondominioNome.TabIndex = 7;
            // 
            // addCondominioSaldo
            // 
            this.addCondominioSaldo.Location = new System.Drawing.Point(452, 115);
            this.addCondominioSaldo.Name = "addCondominioSaldo";
            this.addCondominioSaldo.Size = new System.Drawing.Size(121, 23);
            this.addCondominioSaldo.TabIndex = 6;
            // 
            // addCondominioEndereco
            // 
            this.addCondominioEndereco.Location = new System.Drawing.Point(0, 193);
            this.addCondominioEndereco.Multiline = true;
            this.addCondominioEndereco.Name = "addCondominioEndereco";
            this.addCondominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addCondominioEndereco.Size = new System.Drawing.Size(573, 111);
            this.addCondominioEndereco.TabIndex = 5;
            // 
            // addCondominioNumRegistro
            // 
            this.addCondominioNumRegistro.Location = new System.Drawing.Point(148, 28);
            this.addCondominioNumRegistro.Name = "addCondominioNumRegistro";
            this.addCondominioNumRegistro.Size = new System.Drawing.Size(121, 23);
            this.addCondominioNumRegistro.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(148, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 15);
            this.label10.TabIndex = 2;
            this.label10.Text = "Número Registro";
            // 
            // addCondominioNumContribuinte
            // 
            this.addCondominioNumContribuinte.Location = new System.Drawing.Point(0, 28);
            this.addCondominioNumContribuinte.Name = "addCondominioNumContribuinte";
            this.addCondominioNumContribuinte.Size = new System.Drawing.Size(121, 23);
            this.addCondominioNumContribuinte.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "Número Contribuinte";
            // 
            // addType
            // 
            this.addType.FormattingEnabled = true;
            this.addType.Items.AddRange(new object[] {
            "Condomínio",
            "Fração"});
            this.addType.Location = new System.Drawing.Point(3, 3);
            this.addType.Name = "addType";
            this.addType.Size = new System.Drawing.Size(121, 23);
            this.addType.TabIndex = 0;
            this.addType.SelectedIndexChanged += new System.EventHandler(this.addType_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.viewAdd);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.viewAdd.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.fracaoPainel.ResumeLayout(false);
            this.fracaoPainel.PerformLayout();
            this.condominioPainel.ResumeLayout(false);
            this.condominioPainel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.addCondominio.ResumeLayout(false);
            this.addCondominio.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl viewAdd;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox condominioListBox;
        private System.Windows.Forms.ComboBox attDropdown;
        private System.Windows.Forms.ListBox attListBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Panel fracaoPainel;
        private System.Windows.Forms.TextBox fracaoEndereco;
        private System.Windows.Forms.Label fracaoEnderecoText;
        private System.Windows.Forms.TextBox fracaoArea;
        private System.Windows.Forms.Label fracaoAreaText;
        private System.Windows.Forms.TextBox fracaoIdentificador;
        private System.Windows.Forms.Label fracaoIdentificadorText;
        private System.Windows.Forms.Panel condominioPainel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox condominioEstado;
        private System.Windows.Forms.TextBox condominioNumRegistro;
        private System.Windows.Forms.TextBox condominioNumContribuinte;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox condominioNome;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox condominioSaldo;
        private System.Windows.Forms.TextBox condominioFim;
        private System.Windows.Forms.TextBox condominioInicio;
        private System.Windows.Forms.TextBox condominioEndereco;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox attSearch;
        private System.Windows.Forms.TextBox condominioSearch;
        private System.Windows.Forms.TextBox secAttSearch;
        private System.Windows.Forms.ComboBox secAttDropdown;
        private System.Windows.Forms.ListBox secAttListBox;
        private System.Windows.Forms.ComboBox addType;
        private System.Windows.Forms.Panel addCondominio;
        private System.Windows.Forms.TextBox addCondominioNumContribuinte;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox addCondominioNumRegistro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox addCondominioInicio;
        private System.Windows.Forms.TextBox addCondominioFim;
        private System.Windows.Forms.TextBox addCondominioNome;
        private System.Windows.Forms.TextBox addCondominioSaldo;
        private System.Windows.Forms.TextBox addCondominioEndereco;
        private System.Windows.Forms.ComboBox addCondominioEstado;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button addButton;
    }
}

