﻿
namespace ProjetoAppV2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewAdd = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.CondominoEmpresa = new System.Windows.Forms.Panel();
            this.CondominoEmpresaNIPC = new System.Windows.Forms.TextBox();
            this.CondominoEmpresaFE = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.CondominoEmpresaIE = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.CondominoEmpresaEmail = new System.Windows.Forms.TextBox();
            this.CondominoEmpresaTelemovel = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.CondominoEmpresaNome = new System.Windows.Forms.TextBox();
            this.CondominoEmpresaEndereco = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.CondominoEmpresaID = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.ProprietarioEmpresa = new System.Windows.Forms.Panel();
            this.ProprietarioEmpresaNIPC = new System.Windows.Forms.TextBox();
            this.ProprietarioEmpresaFE = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.ProprietarioEmpresaIE = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.ProprietarioEmpresaEmail = new System.Windows.Forms.TextBox();
            this.ProprietarioEmpresaTelemovel = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.ProprietarioEmpresaNome = new System.Windows.Forms.TextBox();
            this.ProprietarioEmpresaEndereco = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.ProprietarioEmpresaID = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.CondominoPessoa = new System.Windows.Forms.Panel();
            this.CondominoPessoaFE = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.CondominoPessoaIE = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.CondominoPessoaDataNasc = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.CondominoPessoaNIF = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.CondominoPessoaEmail = new System.Windows.Forms.TextBox();
            this.CondominoPessoaG = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.CondominoPessoaNumCC = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.CondominoPessoaTelemovel = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.CondominoPessoaNome = new System.Windows.Forms.TextBox();
            this.CondominoPessoaEndereco = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.CondominoPessoaID = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.ProprietarioPessoa = new System.Windows.Forms.Panel();
            this.ProprietarioPessoaFE = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaIE = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaDataNascimento = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaNIF = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaEmail = new System.Windows.Forms.TextBox();
            this.ProprietarioPessoaG = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaNumCC = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaTelemovel = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaNome = new System.Windows.Forms.TextBox();
            this.ProprietarioPessoaEndereco = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.ProprietarioPessoaID = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.secAttDropdown = new System.Windows.Forms.ComboBox();
            this.secAttListBox = new System.Windows.Forms.ListBox();
            this.condominioSearch = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.attDropdown = new System.Windows.Forms.ComboBox();
            this.attListBox = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.condominioListBox = new System.Windows.Forms.ListBox();
            this.fracaoPainel = new System.Windows.Forms.Panel();
            this.fracaoEndereco = new System.Windows.Forms.TextBox();
            this.fracaoEnderecoText = new System.Windows.Forms.Label();
            this.fracaoArea = new System.Windows.Forms.TextBox();
            this.fracaoAreaText = new System.Windows.Forms.Label();
            this.fracaoIdentificador = new System.Windows.Forms.TextBox();
            this.fracaoIdentificadorText = new System.Windows.Forms.Label();
            this.condominioPainel = new System.Windows.Forms.Panel();
            this.condominioEndereco = new System.Windows.Forms.TextBox();
            this.condominioSaldo = new System.Windows.Forms.TextBox();
            this.condominioFim = new System.Windows.Forms.TextBox();
            this.condominioInicio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.condominioNome = new System.Windows.Forms.TextBox();
            this.condominioEstado = new System.Windows.Forms.TextBox();
            this.condominioNumRegistro = new System.Windows.Forms.TextBox();
            this.condominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.addButton = new System.Windows.Forms.Button();
            this.addType = new System.Windows.Forms.ComboBox();
            this.addSeguro = new System.Windows.Forms.Panel();
            this.addSeguroCondominio = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.addSeguroFracao = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.addSeguroCapitalF = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.addSeguroCapitalO = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.addSeguroDesignacao = new System.Windows.Forms.TextBox();
            this.addSeguroTipo = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.addSeguroNome = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.addSeguroNumApolice = new System.Windows.Forms.TextBox();
            this.addPessoa = new System.Windows.Forms.Panel();
            this.addPessoaDataNascimento = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.addPessoaGenero = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.addPessoaNumCC = new System.Windows.Forms.TextBox();
            this.addPessoaNIF = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.addPessoaEndereco = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.addPessoaEmail = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.addPessoaTelemovel = new System.Windows.Forms.TextBox();
            this.addPessoaNome = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.addPessoaIdentificador = new System.Windows.Forms.TextBox();
            this.addEmpresa = new System.Windows.Forms.Panel();
            this.addEmpresaNIPC = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.addEmpresaEndereco = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.addEmpresaEmail = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.addEmpresaTelemovel = new System.Windows.Forms.TextBox();
            this.addEmpresaNome = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.addEmpresaIdentificador = new System.Windows.Forms.TextBox();
            this.addFracao = new System.Windows.Forms.Panel();
            this.addFracaoZona = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.addFracaoCondominio = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.addFracaoLocalizacao = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.addFracaoProprietario = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.addFracaoArea = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.addFracaoIdentificador = new System.Windows.Forms.TextBox();
            this.addCondominio = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.addCondominioEstado = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.addCondominioInicio = new System.Windows.Forms.TextBox();
            this.addCondominioFim = new System.Windows.Forms.TextBox();
            this.addCondominioNome = new System.Windows.Forms.TextBox();
            this.addCondominioSaldo = new System.Windows.Forms.TextBox();
            this.addCondominioEndereco = new System.Windows.Forms.TextBox();
            this.addCondominioNumRegistro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.addCondominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.addZona = new System.Windows.Forms.Panel();
            this.addZonaDesignacao = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.addZonaCodigo = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.addServico = new System.Windows.Forms.Panel();
            this.addServicoPagamento = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.addServicoHoras = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.addServicoCusto = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.addServicoDesignacao = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.addServicoCodigo = new System.Windows.Forms.TextBox();
            this.Código = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.viewAdd.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.CondominoEmpresa.SuspendLayout();
            this.ProprietarioEmpresa.SuspendLayout();
            this.CondominoPessoa.SuspendLayout();
            this.ProprietarioPessoa.SuspendLayout();
            this.fracaoPainel.SuspendLayout();
            this.condominioPainel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.addSeguro.SuspendLayout();
            this.addPessoa.SuspendLayout();
            this.addEmpresa.SuspendLayout();
            this.addFracao.SuspendLayout();
            this.addCondominio.SuspendLayout();
            this.addZona.SuspendLayout();
            this.addServico.SuspendLayout();
            this.SuspendLayout();
            // 
            // viewAdd
            // 
            this.viewAdd.Controls.Add(this.tabPage1);
            this.viewAdd.Controls.Add(this.tabPage2);
            this.viewAdd.Location = new System.Drawing.Point(14, 16);
            this.viewAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.viewAdd.Name = "viewAdd";
            this.viewAdd.SelectedIndex = 0;
            this.viewAdd.Size = new System.Drawing.Size(887, 568);
            this.viewAdd.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.CondominoEmpresa);
            this.tabPage1.Controls.Add(this.ProprietarioEmpresa);
            this.tabPage1.Controls.Add(this.CondominoPessoa);
            this.tabPage1.Controls.Add(this.ProprietarioPessoa);
            this.tabPage1.Controls.Add(this.secAttDropdown);
            this.tabPage1.Controls.Add(this.secAttListBox);
            this.tabPage1.Controls.Add(this.condominioSearch);
            this.tabPage1.Controls.Add(this.cancelButton);
            this.tabPage1.Controls.Add(this.saveButton);
            this.tabPage1.Controls.Add(this.editButton);
            this.tabPage1.Controls.Add(this.removeButton);
            this.tabPage1.Controls.Add(this.attDropdown);
            this.tabPage1.Controls.Add(this.attListBox);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.condominioListBox);
            this.tabPage1.Controls.Add(this.fracaoPainel);
            this.tabPage1.Controls.Add(this.condominioPainel);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(879, 535);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label90);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label91);
            this.panel1.Controls.Add(this.label93);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.label94);
            this.panel1.Controls.Add(this.label95);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.label97);
            this.panel1.Location = new System.Drawing.Point(476, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 470);
            this.panel1.TabIndex = 54;
            this.panel1.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(249, 276);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(126, 27);
            this.textBox2.TabIndex = 49;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label90.Location = new System.Drawing.Point(250, 254);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(131, 20);
            this.label90.TabIndex = 50;
            this.label90.Text = "Capital Facultativo";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(13, 276);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(125, 27);
            this.textBox3.TabIndex = 47;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label91.Location = new System.Drawing.Point(14, 254);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(138, 20);
            this.label91.TabIndex = 48;
            this.label91.Text = "Capital Obrigatório";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label93.Location = new System.Drawing.Point(15, 182);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(87, 20);
            this.label93.TabIndex = 42;
            this.label93.Text = "Designação";
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Location = new System.Drawing.Point(12, 205);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(363, 27);
            this.textBox4.TabIndex = 41;
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Location = new System.Drawing.Point(248, 71);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(126, 27);
            this.textBox5.TabIndex = 28;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label94.Location = new System.Drawing.Point(246, 48);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(39, 20);
            this.label94.TabIndex = 29;
            this.label94.Text = "Tipo";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label95.Location = new System.Drawing.Point(13, 116);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(151, 20);
            this.label95.TabIndex = 27;
            this.label95.Text = "Nome da Companhia";
            // 
            // textBox6
            // 
            this.textBox6.Enabled = false;
            this.textBox6.Location = new System.Drawing.Point(12, 139);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(363, 27);
            this.textBox6.TabIndex = 26;
            // 
            // textBox8
            // 
            this.textBox8.Enabled = false;
            this.textBox8.Location = new System.Drawing.Point(12, 72);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(97, 27);
            this.textBox8.TabIndex = 20;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label97.Location = new System.Drawing.Point(9, 49);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(99, 20);
            this.label97.TabIndex = 21;
            this.label97.Text = "Num. Apolice";
            // 
            // CondominoEmpresa
            // 
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaNIPC);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaFE);
            this.CondominoEmpresa.Controls.Add(this.label76);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaIE);
            this.CondominoEmpresa.Controls.Add(this.label79);
            this.CondominoEmpresa.Controls.Add(this.label80);
            this.CondominoEmpresa.Controls.Add(this.label85);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaEmail);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaTelemovel);
            this.CondominoEmpresa.Controls.Add(this.label86);
            this.CondominoEmpresa.Controls.Add(this.label87);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaNome);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaEndereco);
            this.CondominoEmpresa.Controls.Add(this.label88);
            this.CondominoEmpresa.Controls.Add(this.CondominoEmpresaID);
            this.CondominoEmpresa.Controls.Add(this.label89);
            this.CondominoEmpresa.Location = new System.Drawing.Point(479, 3);
            this.CondominoEmpresa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresa.Name = "CondominoEmpresa";
            this.CondominoEmpresa.Size = new System.Drawing.Size(400, 470);
            this.CondominoEmpresa.TabIndex = 53;
            this.CondominoEmpresa.Visible = false;
            // 
            // CondominoEmpresaNIPC
            // 
            this.CondominoEmpresaNIPC.Enabled = false;
            this.CondominoEmpresaNIPC.Location = new System.Drawing.Point(114, 72);
            this.CondominoEmpresaNIPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaNIPC.Name = "CondominoEmpresaNIPC";
            this.CondominoEmpresaNIPC.Size = new System.Drawing.Size(129, 27);
            this.CondominoEmpresaNIPC.TabIndex = 51;
            // 
            // CondominoEmpresaFE
            // 
            this.CondominoEmpresaFE.Enabled = false;
            this.CondominoEmpresaFE.Location = new System.Drawing.Point(249, 276);
            this.CondominoEmpresaFE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaFE.Name = "CondominoEmpresaFE";
            this.CondominoEmpresaFE.Size = new System.Drawing.Size(126, 27);
            this.CondominoEmpresaFE.TabIndex = 49;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label76.Location = new System.Drawing.Point(250, 254);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(118, 20);
            this.label76.TabIndex = 50;
            this.label76.Text = "Fim do Exercicio";
            // 
            // CondominoEmpresaIE
            // 
            this.CondominoEmpresaIE.Enabled = false;
            this.CondominoEmpresaIE.Location = new System.Drawing.Point(13, 276);
            this.CondominoEmpresaIE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaIE.Name = "CondominoEmpresaIE";
            this.CondominoEmpresaIE.Size = new System.Drawing.Size(125, 27);
            this.CondominoEmpresaIE.TabIndex = 47;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label79.Location = new System.Drawing.Point(14, 254);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(130, 20);
            this.label79.TabIndex = 48;
            this.label79.Text = "Início do Exercicio";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label80.Location = new System.Drawing.Point(113, 49);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(41, 20);
            this.label80.TabIndex = 44;
            this.label80.Text = "NIPC";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label85.Location = new System.Drawing.Point(15, 182);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(46, 20);
            this.label85.TabIndex = 42;
            this.label85.Text = "Email";
            // 
            // CondominoEmpresaEmail
            // 
            this.CondominoEmpresaEmail.Enabled = false;
            this.CondominoEmpresaEmail.Location = new System.Drawing.Point(12, 205);
            this.CondominoEmpresaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaEmail.Name = "CondominoEmpresaEmail";
            this.CondominoEmpresaEmail.Size = new System.Drawing.Size(363, 27);
            this.CondominoEmpresaEmail.TabIndex = 41;
            // 
            // CondominoEmpresaTelemovel
            // 
            this.CondominoEmpresaTelemovel.Enabled = false;
            this.CondominoEmpresaTelemovel.Location = new System.Drawing.Point(248, 71);
            this.CondominoEmpresaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaTelemovel.Name = "CondominoEmpresaTelemovel";
            this.CondominoEmpresaTelemovel.Size = new System.Drawing.Size(126, 27);
            this.CondominoEmpresaTelemovel.TabIndex = 28;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label86.Location = new System.Drawing.Point(246, 48);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(77, 20);
            this.label86.TabIndex = 29;
            this.label86.Text = "Telemóvel";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label87.Location = new System.Drawing.Point(13, 116);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(50, 20);
            this.label87.TabIndex = 27;
            this.label87.Text = "Nome";
            // 
            // CondominoEmpresaNome
            // 
            this.CondominoEmpresaNome.Enabled = false;
            this.CondominoEmpresaNome.Location = new System.Drawing.Point(12, 139);
            this.CondominoEmpresaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaNome.Name = "CondominoEmpresaNome";
            this.CondominoEmpresaNome.Size = new System.Drawing.Size(363, 27);
            this.CondominoEmpresaNome.TabIndex = 26;
            // 
            // CondominoEmpresaEndereco
            // 
            this.CondominoEmpresaEndereco.Enabled = false;
            this.CondominoEmpresaEndereco.Location = new System.Drawing.Point(13, 341);
            this.CondominoEmpresaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaEndereco.Multiline = true;
            this.CondominoEmpresaEndereco.Name = "CondominoEmpresaEndereco";
            this.CondominoEmpresaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CondominoEmpresaEndereco.Size = new System.Drawing.Size(364, 60);
            this.CondominoEmpresaEndereco.TabIndex = 25;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label88.Location = new System.Drawing.Point(8, 317);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(71, 20);
            this.label88.TabIndex = 24;
            this.label88.Text = "Endereço";
            // 
            // CondominoEmpresaID
            // 
            this.CondominoEmpresaID.Enabled = false;
            this.CondominoEmpresaID.Location = new System.Drawing.Point(12, 72);
            this.CondominoEmpresaID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoEmpresaID.Name = "CondominoEmpresaID";
            this.CondominoEmpresaID.Size = new System.Drawing.Size(97, 27);
            this.CondominoEmpresaID.TabIndex = 20;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label89.Location = new System.Drawing.Point(9, 49);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(24, 20);
            this.label89.TabIndex = 21;
            this.label89.Text = "ID";
            // 
            // ProprietarioEmpresa
            // 
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaNIPC);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaFE);
            this.ProprietarioEmpresa.Controls.Add(this.label74);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaIE);
            this.ProprietarioEmpresa.Controls.Add(this.label75);
            this.ProprietarioEmpresa.Controls.Add(this.label77);
            this.ProprietarioEmpresa.Controls.Add(this.label78);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaEmail);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaTelemovel);
            this.ProprietarioEmpresa.Controls.Add(this.label81);
            this.ProprietarioEmpresa.Controls.Add(this.label82);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaNome);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaEndereco);
            this.ProprietarioEmpresa.Controls.Add(this.label83);
            this.ProprietarioEmpresa.Controls.Add(this.ProprietarioEmpresaID);
            this.ProprietarioEmpresa.Controls.Add(this.label84);
            this.ProprietarioEmpresa.Location = new System.Drawing.Point(479, 1);
            this.ProprietarioEmpresa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresa.Name = "ProprietarioEmpresa";
            this.ProprietarioEmpresa.Size = new System.Drawing.Size(400, 470);
            this.ProprietarioEmpresa.TabIndex = 52;
            this.ProprietarioEmpresa.Visible = false;
            // 
            // ProprietarioEmpresaNIPC
            // 
            this.ProprietarioEmpresaNIPC.Enabled = false;
            this.ProprietarioEmpresaNIPC.Location = new System.Drawing.Point(114, 72);
            this.ProprietarioEmpresaNIPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaNIPC.Name = "ProprietarioEmpresaNIPC";
            this.ProprietarioEmpresaNIPC.Size = new System.Drawing.Size(129, 27);
            this.ProprietarioEmpresaNIPC.TabIndex = 51;
            // 
            // ProprietarioEmpresaFE
            // 
            this.ProprietarioEmpresaFE.Enabled = false;
            this.ProprietarioEmpresaFE.Location = new System.Drawing.Point(249, 276);
            this.ProprietarioEmpresaFE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaFE.Name = "ProprietarioEmpresaFE";
            this.ProprietarioEmpresaFE.Size = new System.Drawing.Size(126, 27);
            this.ProprietarioEmpresaFE.TabIndex = 49;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label74.Location = new System.Drawing.Point(250, 254);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(118, 20);
            this.label74.TabIndex = 50;
            this.label74.Text = "Fim do Exercicio";
            // 
            // ProprietarioEmpresaIE
            // 
            this.ProprietarioEmpresaIE.Enabled = false;
            this.ProprietarioEmpresaIE.Location = new System.Drawing.Point(13, 276);
            this.ProprietarioEmpresaIE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaIE.Name = "ProprietarioEmpresaIE";
            this.ProprietarioEmpresaIE.Size = new System.Drawing.Size(125, 27);
            this.ProprietarioEmpresaIE.TabIndex = 47;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label75.Location = new System.Drawing.Point(14, 254);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(130, 20);
            this.label75.TabIndex = 48;
            this.label75.Text = "Início do Exercicio";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label77.Location = new System.Drawing.Point(113, 49);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(41, 20);
            this.label77.TabIndex = 44;
            this.label77.Text = "NIPC";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label78.Location = new System.Drawing.Point(15, 182);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(46, 20);
            this.label78.TabIndex = 42;
            this.label78.Text = "Email";
            // 
            // ProprietarioEmpresaEmail
            // 
            this.ProprietarioEmpresaEmail.Enabled = false;
            this.ProprietarioEmpresaEmail.Location = new System.Drawing.Point(12, 205);
            this.ProprietarioEmpresaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaEmail.Name = "ProprietarioEmpresaEmail";
            this.ProprietarioEmpresaEmail.Size = new System.Drawing.Size(363, 27);
            this.ProprietarioEmpresaEmail.TabIndex = 41;
            // 
            // ProprietarioEmpresaTelemovel
            // 
            this.ProprietarioEmpresaTelemovel.Enabled = false;
            this.ProprietarioEmpresaTelemovel.Location = new System.Drawing.Point(248, 71);
            this.ProprietarioEmpresaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaTelemovel.Name = "ProprietarioEmpresaTelemovel";
            this.ProprietarioEmpresaTelemovel.Size = new System.Drawing.Size(126, 27);
            this.ProprietarioEmpresaTelemovel.TabIndex = 28;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label81.Location = new System.Drawing.Point(246, 48);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(77, 20);
            this.label81.TabIndex = 29;
            this.label81.Text = "Telemóvel";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label82.Location = new System.Drawing.Point(13, 116);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(50, 20);
            this.label82.TabIndex = 27;
            this.label82.Text = "Nome";
            // 
            // ProprietarioEmpresaNome
            // 
            this.ProprietarioEmpresaNome.Enabled = false;
            this.ProprietarioEmpresaNome.Location = new System.Drawing.Point(12, 139);
            this.ProprietarioEmpresaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaNome.Name = "ProprietarioEmpresaNome";
            this.ProprietarioEmpresaNome.Size = new System.Drawing.Size(363, 27);
            this.ProprietarioEmpresaNome.TabIndex = 26;
            // 
            // ProprietarioEmpresaEndereco
            // 
            this.ProprietarioEmpresaEndereco.Enabled = false;
            this.ProprietarioEmpresaEndereco.Location = new System.Drawing.Point(13, 341);
            this.ProprietarioEmpresaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaEndereco.Multiline = true;
            this.ProprietarioEmpresaEndereco.Name = "ProprietarioEmpresaEndereco";
            this.ProprietarioEmpresaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ProprietarioEmpresaEndereco.Size = new System.Drawing.Size(364, 60);
            this.ProprietarioEmpresaEndereco.TabIndex = 25;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label83.Location = new System.Drawing.Point(8, 317);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(71, 20);
            this.label83.TabIndex = 24;
            this.label83.Text = "Endereço";
            // 
            // ProprietarioEmpresaID
            // 
            this.ProprietarioEmpresaID.Enabled = false;
            this.ProprietarioEmpresaID.Location = new System.Drawing.Point(12, 72);
            this.ProprietarioEmpresaID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioEmpresaID.Name = "ProprietarioEmpresaID";
            this.ProprietarioEmpresaID.Size = new System.Drawing.Size(97, 27);
            this.ProprietarioEmpresaID.TabIndex = 20;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label84.Location = new System.Drawing.Point(9, 49);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(24, 20);
            this.label84.TabIndex = 21;
            this.label84.Text = "ID";
            // 
            // CondominoPessoa
            // 
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaFE);
            this.CondominoPessoa.Controls.Add(this.label53);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaIE);
            this.CondominoPessoa.Controls.Add(this.label64);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaDataNasc);
            this.CondominoPessoa.Controls.Add(this.label65);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaNIF);
            this.CondominoPessoa.Controls.Add(this.label66);
            this.CondominoPessoa.Controls.Add(this.label67);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaEmail);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaG);
            this.CondominoPessoa.Controls.Add(this.label68);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaNumCC);
            this.CondominoPessoa.Controls.Add(this.label69);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaTelemovel);
            this.CondominoPessoa.Controls.Add(this.label70);
            this.CondominoPessoa.Controls.Add(this.label71);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaNome);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaEndereco);
            this.CondominoPessoa.Controls.Add(this.label72);
            this.CondominoPessoa.Controls.Add(this.CondominoPessoaID);
            this.CondominoPessoa.Controls.Add(this.label73);
            this.CondominoPessoa.Location = new System.Drawing.Point(479, 0);
            this.CondominoPessoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoa.Name = "CondominoPessoa";
            this.CondominoPessoa.Size = new System.Drawing.Size(400, 470);
            this.CondominoPessoa.TabIndex = 51;
            this.CondominoPessoa.Visible = false;
            // 
            // CondominoPessoaFE
            // 
            this.CondominoPessoaFE.Enabled = false;
            this.CondominoPessoaFE.Location = new System.Drawing.Point(249, 345);
            this.CondominoPessoaFE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaFE.Name = "CondominoPessoaFE";
            this.CondominoPessoaFE.Size = new System.Drawing.Size(125, 27);
            this.CondominoPessoaFE.TabIndex = 49;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label53.Location = new System.Drawing.Point(250, 323);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(118, 20);
            this.label53.TabIndex = 50;
            this.label53.Text = "Fim do Exercicio";
            // 
            // CondominoPessoaIE
            // 
            this.CondominoPessoaIE.Enabled = false;
            this.CondominoPessoaIE.Location = new System.Drawing.Point(13, 345);
            this.CondominoPessoaIE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaIE.Name = "CondominoPessoaIE";
            this.CondominoPessoaIE.Size = new System.Drawing.Size(125, 27);
            this.CondominoPessoaIE.TabIndex = 47;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label64.Location = new System.Drawing.Point(14, 323);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(130, 20);
            this.label64.TabIndex = 48;
            this.label64.Text = "Início do Exercicio";
            // 
            // CondominoPessoaDataNasc
            // 
            this.CondominoPessoaDataNasc.Enabled = false;
            this.CondominoPessoaDataNasc.Location = new System.Drawing.Point(270, 277);
            this.CondominoPessoaDataNasc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaDataNasc.Name = "CondominoPessoaDataNasc";
            this.CondominoPessoaDataNasc.Size = new System.Drawing.Size(105, 27);
            this.CondominoPessoaDataNasc.TabIndex = 45;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label65.Location = new System.Drawing.Point(270, 253);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(94, 20);
            this.label65.TabIndex = 46;
            this.label65.Text = "Data de Nas.";
            // 
            // CondominoPessoaNIF
            // 
            this.CondominoPessoaNIF.Enabled = false;
            this.CondominoPessoaNIF.Location = new System.Drawing.Point(148, 277);
            this.CondominoPessoaNIF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaNIF.Name = "CondominoPessoaNIF";
            this.CondominoPessoaNIF.Size = new System.Drawing.Size(109, 27);
            this.CondominoPessoaNIF.TabIndex = 43;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label66.Location = new System.Drawing.Point(146, 255);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(31, 20);
            this.label66.TabIndex = 44;
            this.label66.Text = "NIF";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label67.Location = new System.Drawing.Point(15, 182);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(46, 20);
            this.label67.TabIndex = 42;
            this.label67.Text = "Email";
            // 
            // CondominoPessoaEmail
            // 
            this.CondominoPessoaEmail.Enabled = false;
            this.CondominoPessoaEmail.Location = new System.Drawing.Point(12, 205);
            this.CondominoPessoaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaEmail.Name = "CondominoPessoaEmail";
            this.CondominoPessoaEmail.Size = new System.Drawing.Size(363, 27);
            this.CondominoPessoaEmail.TabIndex = 41;
            // 
            // CondominoPessoaG
            // 
            this.CondominoPessoaG.Enabled = false;
            this.CondominoPessoaG.Location = new System.Drawing.Point(124, 72);
            this.CondominoPessoaG.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaG.Name = "CondominoPessoaG";
            this.CondominoPessoaG.Size = new System.Drawing.Size(100, 27);
            this.CondominoPessoaG.TabIndex = 40;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label68.Location = new System.Drawing.Point(125, 51);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(57, 20);
            this.label68.TabIndex = 39;
            this.label68.Text = "Género";
            // 
            // CondominoPessoaNumCC
            // 
            this.CondominoPessoaNumCC.Enabled = false;
            this.CondominoPessoaNumCC.Location = new System.Drawing.Point(12, 277);
            this.CondominoPessoaNumCC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaNumCC.Name = "CondominoPessoaNumCC";
            this.CondominoPessoaNumCC.Size = new System.Drawing.Size(125, 27);
            this.CondominoPessoaNumCC.TabIndex = 36;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label69.Location = new System.Drawing.Point(13, 255);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(85, 20);
            this.label69.TabIndex = 37;
            this.label69.Text = "Número CC";
            // 
            // CondominoPessoaTelemovel
            // 
            this.CondominoPessoaTelemovel.Enabled = false;
            this.CondominoPessoaTelemovel.Location = new System.Drawing.Point(249, 73);
            this.CondominoPessoaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaTelemovel.Name = "CondominoPessoaTelemovel";
            this.CondominoPessoaTelemovel.Size = new System.Drawing.Size(126, 27);
            this.CondominoPessoaTelemovel.TabIndex = 28;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label70.Location = new System.Drawing.Point(246, 50);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(77, 20);
            this.label70.TabIndex = 29;
            this.label70.Text = "Telemóvel";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label71.Location = new System.Drawing.Point(13, 116);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(50, 20);
            this.label71.TabIndex = 27;
            this.label71.Text = "Nome";
            // 
            // CondominoPessoaNome
            // 
            this.CondominoPessoaNome.Enabled = false;
            this.CondominoPessoaNome.Location = new System.Drawing.Point(12, 139);
            this.CondominoPessoaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaNome.Name = "CondominoPessoaNome";
            this.CondominoPessoaNome.Size = new System.Drawing.Size(363, 27);
            this.CondominoPessoaNome.TabIndex = 26;
            // 
            // CondominoPessoaEndereco
            // 
            this.CondominoPessoaEndereco.Enabled = false;
            this.CondominoPessoaEndereco.Location = new System.Drawing.Point(13, 406);
            this.CondominoPessoaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaEndereco.Multiline = true;
            this.CondominoPessoaEndereco.Name = "CondominoPessoaEndereco";
            this.CondominoPessoaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CondominoPessoaEndereco.Size = new System.Drawing.Size(359, 60);
            this.CondominoPessoaEndereco.TabIndex = 25;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label72.Location = new System.Drawing.Point(13, 382);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(71, 20);
            this.label72.TabIndex = 24;
            this.label72.Text = "Endereço";
            // 
            // CondominoPessoaID
            // 
            this.CondominoPessoaID.Enabled = false;
            this.CondominoPessoaID.Location = new System.Drawing.Point(12, 72);
            this.CondominoPessoaID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CondominoPessoaID.Name = "CondominoPessoaID";
            this.CondominoPessoaID.Size = new System.Drawing.Size(86, 27);
            this.CondominoPessoaID.TabIndex = 20;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label73.Location = new System.Drawing.Point(9, 49);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(24, 20);
            this.label73.TabIndex = 21;
            this.label73.Text = "ID";
            // 
            // ProprietarioPessoa
            // 
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaFE);
            this.ProprietarioPessoa.Controls.Add(this.label63);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaIE);
            this.ProprietarioPessoa.Controls.Add(this.label60);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaDataNascimento);
            this.ProprietarioPessoa.Controls.Add(this.label58);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaNIF);
            this.ProprietarioPessoa.Controls.Add(this.label56);
            this.ProprietarioPessoa.Controls.Add(this.label62);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaEmail);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaG);
            this.ProprietarioPessoa.Controls.Add(this.label61);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaNumCC);
            this.ProprietarioPessoa.Controls.Add(this.label59);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaTelemovel);
            this.ProprietarioPessoa.Controls.Add(this.label57);
            this.ProprietarioPessoa.Controls.Add(this.label55);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaNome);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaEndereco);
            this.ProprietarioPessoa.Controls.Add(this.label52);
            this.ProprietarioPessoa.Controls.Add(this.ProprietarioPessoaID);
            this.ProprietarioPessoa.Controls.Add(this.label54);
            this.ProprietarioPessoa.Location = new System.Drawing.Point(484, 0);
            this.ProprietarioPessoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoa.Name = "ProprietarioPessoa";
            this.ProprietarioPessoa.Size = new System.Drawing.Size(400, 470);
            this.ProprietarioPessoa.TabIndex = 26;
            this.ProprietarioPessoa.Visible = false;
            // 
            // ProprietarioPessoaFE
            // 
            this.ProprietarioPessoaFE.Enabled = false;
            this.ProprietarioPessoaFE.Location = new System.Drawing.Point(249, 345);
            this.ProprietarioPessoaFE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaFE.Name = "ProprietarioPessoaFE";
            this.ProprietarioPessoaFE.Size = new System.Drawing.Size(125, 27);
            this.ProprietarioPessoaFE.TabIndex = 49;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label63.Location = new System.Drawing.Point(250, 323);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(118, 20);
            this.label63.TabIndex = 50;
            this.label63.Text = "Fim do Exercicio";
            // 
            // ProprietarioPessoaIE
            // 
            this.ProprietarioPessoaIE.Enabled = false;
            this.ProprietarioPessoaIE.Location = new System.Drawing.Point(13, 345);
            this.ProprietarioPessoaIE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaIE.Name = "ProprietarioPessoaIE";
            this.ProprietarioPessoaIE.Size = new System.Drawing.Size(125, 27);
            this.ProprietarioPessoaIE.TabIndex = 47;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label60.Location = new System.Drawing.Point(14, 323);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(130, 20);
            this.label60.TabIndex = 48;
            this.label60.Text = "Início do Exercicio";
            // 
            // ProprietarioPessoaDataNascimento
            // 
            this.ProprietarioPessoaDataNascimento.Enabled = false;
            this.ProprietarioPessoaDataNascimento.Location = new System.Drawing.Point(270, 277);
            this.ProprietarioPessoaDataNascimento.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaDataNascimento.Name = "ProprietarioPessoaDataNascimento";
            this.ProprietarioPessoaDataNascimento.Size = new System.Drawing.Size(105, 27);
            this.ProprietarioPessoaDataNascimento.TabIndex = 45;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label58.Location = new System.Drawing.Point(270, 253);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(94, 20);
            this.label58.TabIndex = 46;
            this.label58.Text = "Data de Nas.";
            // 
            // ProprietarioPessoaNIF
            // 
            this.ProprietarioPessoaNIF.Enabled = false;
            this.ProprietarioPessoaNIF.Location = new System.Drawing.Point(148, 277);
            this.ProprietarioPessoaNIF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaNIF.Name = "ProprietarioPessoaNIF";
            this.ProprietarioPessoaNIF.Size = new System.Drawing.Size(109, 27);
            this.ProprietarioPessoaNIF.TabIndex = 43;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label56.Location = new System.Drawing.Point(146, 255);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(31, 20);
            this.label56.TabIndex = 44;
            this.label56.Text = "NIF";
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label62.Location = new System.Drawing.Point(15, 182);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(46, 20);
            this.label62.TabIndex = 42;
            this.label62.Text = "Email";
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // ProprietarioPessoaEmail
            // 
            this.ProprietarioPessoaEmail.Enabled = false;
            this.ProprietarioPessoaEmail.Location = new System.Drawing.Point(12, 205);
            this.ProprietarioPessoaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaEmail.Name = "ProprietarioPessoaEmail";
            this.ProprietarioPessoaEmail.Size = new System.Drawing.Size(363, 27);
            this.ProprietarioPessoaEmail.TabIndex = 41;
            // 
            // ProprietarioPessoaG
            // 
            this.ProprietarioPessoaG.Enabled = false;
            this.ProprietarioPessoaG.Location = new System.Drawing.Point(124, 72);
            this.ProprietarioPessoaG.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaG.Name = "ProprietarioPessoaG";
            this.ProprietarioPessoaG.Size = new System.Drawing.Size(100, 27);
            this.ProprietarioPessoaG.TabIndex = 40;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label61.Location = new System.Drawing.Point(125, 51);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(57, 20);
            this.label61.TabIndex = 39;
            this.label61.Text = "Género";
            // 
            // ProprietarioPessoaNumCC
            // 
            this.ProprietarioPessoaNumCC.Enabled = false;
            this.ProprietarioPessoaNumCC.Location = new System.Drawing.Point(12, 277);
            this.ProprietarioPessoaNumCC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaNumCC.Name = "ProprietarioPessoaNumCC";
            this.ProprietarioPessoaNumCC.Size = new System.Drawing.Size(125, 27);
            this.ProprietarioPessoaNumCC.TabIndex = 36;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label59.Location = new System.Drawing.Point(13, 255);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(85, 20);
            this.label59.TabIndex = 37;
            this.label59.Text = "Número CC";
            // 
            // ProprietarioPessoaTelemovel
            // 
            this.ProprietarioPessoaTelemovel.Enabled = false;
            this.ProprietarioPessoaTelemovel.Location = new System.Drawing.Point(249, 73);
            this.ProprietarioPessoaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaTelemovel.Name = "ProprietarioPessoaTelemovel";
            this.ProprietarioPessoaTelemovel.Size = new System.Drawing.Size(126, 27);
            this.ProprietarioPessoaTelemovel.TabIndex = 28;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label57.Location = new System.Drawing.Point(246, 50);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(77, 20);
            this.label57.TabIndex = 29;
            this.label57.Text = "Telemóvel";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label55.Location = new System.Drawing.Point(13, 116);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(50, 20);
            this.label55.TabIndex = 27;
            this.label55.Text = "Nome";
            // 
            // ProprietarioPessoaNome
            // 
            this.ProprietarioPessoaNome.Enabled = false;
            this.ProprietarioPessoaNome.Location = new System.Drawing.Point(12, 139);
            this.ProprietarioPessoaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaNome.Name = "ProprietarioPessoaNome";
            this.ProprietarioPessoaNome.Size = new System.Drawing.Size(363, 27);
            this.ProprietarioPessoaNome.TabIndex = 26;
            // 
            // ProprietarioPessoaEndereco
            // 
            this.ProprietarioPessoaEndereco.Enabled = false;
            this.ProprietarioPessoaEndereco.Location = new System.Drawing.Point(13, 406);
            this.ProprietarioPessoaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaEndereco.Multiline = true;
            this.ProprietarioPessoaEndereco.Name = "ProprietarioPessoaEndereco";
            this.ProprietarioPessoaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ProprietarioPessoaEndereco.Size = new System.Drawing.Size(359, 60);
            this.ProprietarioPessoaEndereco.TabIndex = 25;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label52.Location = new System.Drawing.Point(13, 382);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(71, 20);
            this.label52.TabIndex = 24;
            this.label52.Text = "Endereço";
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // ProprietarioPessoaID
            // 
            this.ProprietarioPessoaID.Enabled = false;
            this.ProprietarioPessoaID.Location = new System.Drawing.Point(12, 72);
            this.ProprietarioPessoaID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProprietarioPessoaID.Name = "ProprietarioPessoaID";
            this.ProprietarioPessoaID.Size = new System.Drawing.Size(86, 27);
            this.ProprietarioPessoaID.TabIndex = 20;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label54.Location = new System.Drawing.Point(9, 49);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(24, 20);
            this.label54.TabIndex = 21;
            this.label54.Text = "ID";
            // 
            // secAttDropdown
            // 
            this.secAttDropdown.FormattingEnabled = true;
            this.secAttDropdown.Location = new System.Drawing.Point(344, 0);
            this.secAttDropdown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.secAttDropdown.Name = "secAttDropdown";
            this.secAttDropdown.Size = new System.Drawing.Size(134, 28);
            this.secAttDropdown.TabIndex = 33;
            this.secAttDropdown.Text = "Atributos";
            this.secAttDropdown.Visible = false;
            this.secAttDropdown.SelectedIndexChanged += new System.EventHandler(this.secAttDropdown_SelectedIndexChanged);
            // 
            // secAttListBox
            // 
            this.secAttListBox.FormattingEnabled = true;
            this.secAttListBox.ItemHeight = 20;
            this.secAttListBox.Location = new System.Drawing.Point(340, 47);
            this.secAttListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.secAttListBox.Name = "secAttListBox";
            this.secAttListBox.Size = new System.Drawing.Size(138, 464);
            this.secAttListBox.TabIndex = 32;
            this.secAttListBox.Visible = false;
            this.secAttListBox.SelectedIndexChanged += new System.EventHandler(this.secAttListBox_SelectedIndexChanged);
            // 
            // condominioSearch
            // 
            this.condominioSearch.Location = new System.Drawing.Point(3, 3);
            this.condominioSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioSearch.Name = "condominioSearch";
            this.condominioSearch.PlaceholderText = "Pesquisa";
            this.condominioSearch.Size = new System.Drawing.Size(114, 27);
            this.condominioSearch.TabIndex = 31;
            this.condominioSearch.TextChanged += new System.EventHandler(this.condominioSearch_TextChanged);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(666, 479);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(86, 31);
            this.cancelButton.TabIndex = 29;
            this.cancelButton.Text = "Cancelar";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Visible = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(771, 479);
            this.saveButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(86, 31);
            this.saveButton.TabIndex = 28;
            this.saveButton.Text = "Salvar";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Visible = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(771, 479);
            this.editButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(86, 31);
            this.editButton.TabIndex = 27;
            this.editButton.Text = "Editar";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Visible = false;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(666, 479);
            this.removeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(86, 31);
            this.removeButton.TabIndex = 20;
            this.removeButton.Text = "Remover";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Visible = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // attDropdown
            // 
            this.attDropdown.FormattingEnabled = true;
            this.attDropdown.Location = new System.Drawing.Point(186, 0);
            this.attDropdown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.attDropdown.Name = "attDropdown";
            this.attDropdown.Size = new System.Drawing.Size(138, 28);
            this.attDropdown.TabIndex = 11;
            this.attDropdown.Text = "Atributos";
            this.attDropdown.SelectedIndexChanged += new System.EventHandler(this.attDropdown_SelectedIndexChanged);
            // 
            // attListBox
            // 
            this.attListBox.FormattingEnabled = true;
            this.attListBox.ItemHeight = 20;
            this.attListBox.Location = new System.Drawing.Point(186, 44);
            this.attListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.attListBox.Name = "attListBox";
            this.attListBox.Size = new System.Drawing.Size(138, 464);
            this.attListBox.TabIndex = 12;
            this.attListBox.Visible = false;
            this.attListBox.SelectedIndexChanged += new System.EventHandler(this.attListBox_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(805, 545);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 13);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // condominioListBox
            // 
            this.condominioListBox.FormattingEnabled = true;
            this.condominioListBox.ItemHeight = 20;
            this.condominioListBox.Location = new System.Drawing.Point(3, 44);
            this.condominioListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioListBox.Name = "condominioListBox";
            this.condominioListBox.Size = new System.Drawing.Size(161, 464);
            this.condominioListBox.TabIndex = 10;
            this.condominioListBox.SelectedIndexChanged += new System.EventHandler(this.condominioListBox_SelectedIndexChanged);
            // 
            // fracaoPainel
            // 
            this.fracaoPainel.Controls.Add(this.fracaoEndereco);
            this.fracaoPainel.Controls.Add(this.fracaoEnderecoText);
            this.fracaoPainel.Controls.Add(this.fracaoArea);
            this.fracaoPainel.Controls.Add(this.fracaoAreaText);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificador);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificadorText);
            this.fracaoPainel.Location = new System.Drawing.Point(531, 4);
            this.fracaoPainel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoPainel.Name = "fracaoPainel";
            this.fracaoPainel.Size = new System.Drawing.Size(343, 467);
            this.fracaoPainel.TabIndex = 21;
            this.fracaoPainel.Visible = false;
            // 
            // fracaoEndereco
            // 
            this.fracaoEndereco.Enabled = false;
            this.fracaoEndereco.Location = new System.Drawing.Point(24, 188);
            this.fracaoEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoEndereco.Multiline = true;
            this.fracaoEndereco.Name = "fracaoEndereco";
            this.fracaoEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.fracaoEndereco.Size = new System.Drawing.Size(316, 243);
            this.fracaoEndereco.TabIndex = 25;
            // 
            // fracaoEnderecoText
            // 
            this.fracaoEnderecoText.AutoSize = true;
            this.fracaoEnderecoText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoEnderecoText.Location = new System.Drawing.Point(24, 140);
            this.fracaoEnderecoText.Name = "fracaoEnderecoText";
            this.fracaoEnderecoText.Size = new System.Drawing.Size(71, 20);
            this.fracaoEnderecoText.TabIndex = 24;
            this.fracaoEnderecoText.Text = "Endereço";
            // 
            // fracaoArea
            // 
            this.fracaoArea.Enabled = false;
            this.fracaoArea.Location = new System.Drawing.Point(185, 79);
            this.fracaoArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoArea.Name = "fracaoArea";
            this.fracaoArea.Size = new System.Drawing.Size(86, 27);
            this.fracaoArea.TabIndex = 23;
            // 
            // fracaoAreaText
            // 
            this.fracaoAreaText.AutoSize = true;
            this.fracaoAreaText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoAreaText.Location = new System.Drawing.Point(185, 40);
            this.fracaoAreaText.Name = "fracaoAreaText";
            this.fracaoAreaText.Size = new System.Drawing.Size(73, 20);
            this.fracaoAreaText.TabIndex = 22;
            this.fracaoAreaText.Text = "Area (m²)";
            // 
            // fracaoIdentificador
            // 
            this.fracaoIdentificador.Enabled = false;
            this.fracaoIdentificador.Location = new System.Drawing.Point(24, 79);
            this.fracaoIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoIdentificador.Name = "fracaoIdentificador";
            this.fracaoIdentificador.Size = new System.Drawing.Size(114, 27);
            this.fracaoIdentificador.TabIndex = 20;
            // 
            // fracaoIdentificadorText
            // 
            this.fracaoIdentificadorText.AutoSize = true;
            this.fracaoIdentificadorText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoIdentificadorText.Location = new System.Drawing.Point(24, 40);
            this.fracaoIdentificadorText.Name = "fracaoIdentificadorText";
            this.fracaoIdentificadorText.Size = new System.Drawing.Size(94, 20);
            this.fracaoIdentificadorText.TabIndex = 21;
            this.fracaoIdentificadorText.Text = "Identificador";
            // 
            // condominioPainel
            // 
            this.condominioPainel.Controls.Add(this.condominioEndereco);
            this.condominioPainel.Controls.Add(this.condominioSaldo);
            this.condominioPainel.Controls.Add(this.condominioFim);
            this.condominioPainel.Controls.Add(this.condominioInicio);
            this.condominioPainel.Controls.Add(this.label8);
            this.condominioPainel.Controls.Add(this.label7);
            this.condominioPainel.Controls.Add(this.label6);
            this.condominioPainel.Controls.Add(this.condominioNome);
            this.condominioPainel.Controls.Add(this.condominioEstado);
            this.condominioPainel.Controls.Add(this.condominioNumRegistro);
            this.condominioPainel.Controls.Add(this.condominioNumContribuinte);
            this.condominioPainel.Controls.Add(this.label5);
            this.condominioPainel.Controls.Add(this.label4);
            this.condominioPainel.Controls.Add(this.label3);
            this.condominioPainel.Controls.Add(this.label2);
            this.condominioPainel.Controls.Add(this.label1);
            this.condominioPainel.Location = new System.Drawing.Point(241, 84);
            this.condominioPainel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioPainel.Name = "condominioPainel";
            this.condominioPainel.Size = new System.Drawing.Size(633, 387);
            this.condominioPainel.TabIndex = 26;
            this.condominioPainel.Visible = false;
            // 
            // condominioEndereco
            // 
            this.condominioEndereco.Enabled = false;
            this.condominioEndereco.Location = new System.Drawing.Point(0, 248);
            this.condominioEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioEndereco.Multiline = true;
            this.condominioEndereco.Name = "condominioEndereco";
            this.condominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.condominioEndereco.Size = new System.Drawing.Size(615, 117);
            this.condominioEndereco.TabIndex = 15;
            // 
            // condominioSaldo
            // 
            this.condominioSaldo.Enabled = false;
            this.condominioSaldo.Location = new System.Drawing.Point(462, 140);
            this.condominioSaldo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioSaldo.Name = "condominioSaldo";
            this.condominioSaldo.Size = new System.Drawing.Size(154, 27);
            this.condominioSaldo.TabIndex = 14;
            // 
            // condominioFim
            // 
            this.condominioFim.Enabled = false;
            this.condominioFim.Location = new System.Drawing.Point(488, 39);
            this.condominioFim.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioFim.Name = "condominioFim";
            this.condominioFim.Size = new System.Drawing.Size(127, 27);
            this.condominioFim.TabIndex = 13;
            // 
            // condominioInicio
            // 
            this.condominioInicio.Enabled = false;
            this.condominioInicio.Location = new System.Drawing.Point(339, 40);
            this.condominioInicio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioInicio.Name = "condominioInicio";
            this.condominioInicio.Size = new System.Drawing.Size(127, 27);
            this.condominioInicio.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(462, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Saldo (€)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(488, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Fim Exercício";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(339, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Início Exercício";
            // 
            // condominioNome
            // 
            this.condominioNome.Enabled = false;
            this.condominioNome.Location = new System.Drawing.Point(0, 140);
            this.condominioNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNome.Name = "condominioNome";
            this.condominioNome.Size = new System.Drawing.Size(437, 27);
            this.condominioNome.TabIndex = 8;
            // 
            // condominioEstado
            // 
            this.condominioEstado.Enabled = false;
            this.condominioEstado.Location = new System.Drawing.Point(243, 40);
            this.condominioEstado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioEstado.Name = "condominioEstado";
            this.condominioEstado.Size = new System.Drawing.Size(76, 27);
            this.condominioEstado.TabIndex = 7;
            // 
            // condominioNumRegistro
            // 
            this.condominioNumRegistro.Enabled = false;
            this.condominioNumRegistro.Location = new System.Drawing.Point(161, 40);
            this.condominioNumRegistro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNumRegistro.Name = "condominioNumRegistro";
            this.condominioNumRegistro.Size = new System.Drawing.Size(62, 27);
            this.condominioNumRegistro.TabIndex = 6;
            // 
            // condominioNumContribuinte
            // 
            this.condominioNumContribuinte.Enabled = false;
            this.condominioNumContribuinte.Location = new System.Drawing.Point(0, 40);
            this.condominioNumContribuinte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNumContribuinte.Name = "condominioNumContribuinte";
            this.condominioNumContribuinte.Size = new System.Drawing.Size(138, 27);
            this.condominioNumContribuinte.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(243, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Estado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Endereço";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número Contribuinte";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.addButton);
            this.tabPage2.Controls.Add(this.addType);
            this.tabPage2.Controls.Add(this.addSeguro);
            this.tabPage2.Controls.Add(this.addPessoa);
            this.tabPage2.Controls.Add(this.addEmpresa);
            this.tabPage2.Controls.Add(this.addFracao);
            this.tabPage2.Controls.Add(this.addCondominio);
            this.tabPage2.Controls.Add(this.addZona);
            this.tabPage2.Controls.Add(this.addServico);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(879, 535);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(789, 491);
            this.addButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(86, 31);
            this.addButton.TabIndex = 2;
            this.addButton.Text = "Adicionar";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // addType
            // 
            this.addType.FormattingEnabled = true;
            this.addType.Items.AddRange(new object[] {
            "Condomínio",
            "Fração",
            "Empresa",
            "Pessoa",
            "Seguro",
            "Serviço",
            "Zona"});
            this.addType.Location = new System.Drawing.Point(3, 4);
            this.addType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addType.Name = "addType";
            this.addType.Size = new System.Drawing.Size(138, 28);
            this.addType.TabIndex = 0;
            this.addType.SelectedIndexChanged += new System.EventHandler(this.addType_SelectedIndexChanged);
            // 
            // addSeguro
            // 
            this.addSeguro.Controls.Add(this.addSeguroCondominio);
            this.addSeguro.Controls.Add(this.label51);
            this.addSeguro.Controls.Add(this.addSeguroFracao);
            this.addSeguro.Controls.Add(this.label50);
            this.addSeguro.Controls.Add(this.label42);
            this.addSeguro.Controls.Add(this.addSeguroCapitalF);
            this.addSeguro.Controls.Add(this.label41);
            this.addSeguro.Controls.Add(this.addSeguroCapitalO);
            this.addSeguro.Controls.Add(this.label40);
            this.addSeguro.Controls.Add(this.addSeguroDesignacao);
            this.addSeguro.Controls.Add(this.addSeguroTipo);
            this.addSeguro.Controls.Add(this.label39);
            this.addSeguro.Controls.Add(this.label38);
            this.addSeguro.Controls.Add(this.addSeguroNome);
            this.addSeguro.Controls.Add(this.label37);
            this.addSeguro.Controls.Add(this.addSeguroNumApolice);
            this.addSeguro.Location = new System.Drawing.Point(0, 57);
            this.addSeguro.Name = "addSeguro";
            this.addSeguro.Size = new System.Drawing.Size(884, 341);
            this.addSeguro.TabIndex = 22;
            // 
            // addSeguroCondominio
            // 
            this.addSeguroCondominio.Location = new System.Drawing.Point(697, 152);
            this.addSeguroCondominio.Name = "addSeguroCondominio";
            this.addSeguroCondominio.Size = new System.Drawing.Size(125, 27);
            this.addSeguroCondominio.TabIndex = 22;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(697, 117);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(91, 20);
            this.label51.TabIndex = 21;
            this.label51.Text = "Condomínio";
            // 
            // addSeguroFracao
            // 
            this.addSeguroFracao.Location = new System.Drawing.Point(524, 152);
            this.addSeguroFracao.Name = "addSeguroFracao";
            this.addSeguroFracao.Size = new System.Drawing.Size(125, 27);
            this.addSeguroFracao.TabIndex = 20;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(524, 117);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(53, 20);
            this.label50.TabIndex = 19;
            this.label50.Text = "Fração";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(10, 220);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(87, 20);
            this.label42.TabIndex = 18;
            this.label42.Text = "Designação";
            // 
            // addSeguroCapitalF
            // 
            this.addSeguroCapitalF.Location = new System.Drawing.Point(220, 153);
            this.addSeguroCapitalF.Name = "addSeguroCapitalF";
            this.addSeguroCapitalF.Size = new System.Drawing.Size(125, 27);
            this.addSeguroCapitalF.TabIndex = 17;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(220, 121);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(131, 20);
            this.label41.TabIndex = 16;
            this.label41.Text = "Capital Facultativo";
            // 
            // addSeguroCapitalO
            // 
            this.addSeguroCapitalO.Location = new System.Drawing.Point(10, 153);
            this.addSeguroCapitalO.Name = "addSeguroCapitalO";
            this.addSeguroCapitalO.Size = new System.Drawing.Size(125, 27);
            this.addSeguroCapitalO.TabIndex = 15;
            this.addSeguroCapitalO.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(10, 121);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(138, 20);
            this.label40.TabIndex = 14;
            this.label40.Text = "Capital Obrigatório";
            // 
            // addSeguroDesignacao
            // 
            this.addSeguroDesignacao.Location = new System.Drawing.Point(10, 257);
            this.addSeguroDesignacao.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addSeguroDesignacao.Multiline = true;
            this.addSeguroDesignacao.Name = "addSeguroDesignacao";
            this.addSeguroDesignacao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addSeguroDesignacao.Size = new System.Drawing.Size(501, 77);
            this.addSeguroDesignacao.TabIndex = 13;
            // 
            // addSeguroTipo
            // 
            this.addSeguroTipo.Location = new System.Drawing.Point(524, 49);
            this.addSeguroTipo.Name = "addSeguroTipo";
            this.addSeguroTipo.Size = new System.Drawing.Size(125, 27);
            this.addSeguroTipo.TabIndex = 9;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(524, 14);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(39, 20);
            this.label39.TabIndex = 8;
            this.label39.Text = "Tipo";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(220, 14);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(151, 20);
            this.label38.TabIndex = 7;
            this.label38.Text = "Nome da Companhia";
            // 
            // addSeguroNome
            // 
            this.addSeguroNome.Location = new System.Drawing.Point(220, 49);
            this.addSeguroNome.Name = "addSeguroNome";
            this.addSeguroNome.Size = new System.Drawing.Size(218, 27);
            this.addSeguroNome.TabIndex = 6;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(10, 14);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(139, 20);
            this.label37.TabIndex = 5;
            this.label37.Text = "Número da Apólice";
            // 
            // addSeguroNumApolice
            // 
            this.addSeguroNumApolice.Location = new System.Drawing.Point(10, 49);
            this.addSeguroNumApolice.Name = "addSeguroNumApolice";
            this.addSeguroNumApolice.Size = new System.Drawing.Size(125, 27);
            this.addSeguroNumApolice.TabIndex = 0;
            // 
            // addPessoa
            // 
            this.addPessoa.Controls.Add(this.addPessoaDataNascimento);
            this.addPessoa.Controls.Add(this.label36);
            this.addPessoa.Controls.Add(this.label35);
            this.addPessoa.Controls.Add(this.addPessoaGenero);
            this.addPessoa.Controls.Add(this.label34);
            this.addPessoa.Controls.Add(this.addPessoaNumCC);
            this.addPessoa.Controls.Add(this.addPessoaNIF);
            this.addPessoa.Controls.Add(this.label28);
            this.addPessoa.Controls.Add(this.label29);
            this.addPessoa.Controls.Add(this.addPessoaEndereco);
            this.addPessoa.Controls.Add(this.label30);
            this.addPessoa.Controls.Add(this.addPessoaEmail);
            this.addPessoa.Controls.Add(this.label31);
            this.addPessoa.Controls.Add(this.addPessoaTelemovel);
            this.addPessoa.Controls.Add(this.addPessoaNome);
            this.addPessoa.Controls.Add(this.label32);
            this.addPessoa.Controls.Add(this.label33);
            this.addPessoa.Controls.Add(this.addPessoaIdentificador);
            this.addPessoa.Location = new System.Drawing.Point(-2, 55);
            this.addPessoa.Name = "addPessoa";
            this.addPessoa.Size = new System.Drawing.Size(888, 377);
            this.addPessoa.TabIndex = 16;
            // 
            // addPessoaDataNascimento
            // 
            this.addPessoaDataNascimento.Location = new System.Drawing.Point(739, 140);
            this.addPessoaDataNascimento.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaDataNascimento.Name = "addPessoaDataNascimento";
            this.addPessoaDataNascimento.Size = new System.Drawing.Size(109, 27);
            this.addPessoaDataNascimento.TabIndex = 21;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(739, 101);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(145, 20);
            this.label36.TabIndex = 20;
            this.label36.Text = "Data de Nascimento";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(566, 101);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 20);
            this.label35.TabIndex = 19;
            this.label35.Text = "Género";
            // 
            // addPessoaGenero
            // 
            this.addPessoaGenero.Location = new System.Drawing.Point(566, 140);
            this.addPessoaGenero.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaGenero.Name = "addPessoaGenero";
            this.addPessoaGenero.Size = new System.Drawing.Size(109, 27);
            this.addPessoaGenero.TabIndex = 18;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(739, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(106, 20);
            this.label34.TabIndex = 17;
            this.label34.Text = "Número de CC";
            // 
            // addPessoaNumCC
            // 
            this.addPessoaNumCC.Location = new System.Drawing.Point(739, 37);
            this.addPessoaNumCC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNumCC.Name = "addPessoaNumCC";
            this.addPessoaNumCC.Size = new System.Drawing.Size(109, 27);
            this.addPessoaNumCC.TabIndex = 16;
            // 
            // addPessoaNIF
            // 
            this.addPessoaNIF.Location = new System.Drawing.Point(566, 37);
            this.addPessoaNIF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNIF.Name = "addPessoaNIF";
            this.addPessoaNIF.Size = new System.Drawing.Size(109, 27);
            this.addPessoaNIF.TabIndex = 15;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(566, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 20);
            this.label28.TabIndex = 14;
            this.label28.Text = "NIF";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 220);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(110, 20);
            this.label29.TabIndex = 13;
            this.label29.Text = "Endereço Atual";
            // 
            // addPessoaEndereco
            // 
            this.addPessoaEndereco.Location = new System.Drawing.Point(6, 244);
            this.addPessoaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaEndereco.Multiline = true;
            this.addPessoaEndereco.Name = "addPessoaEndereco";
            this.addPessoaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addPessoaEndereco.Size = new System.Drawing.Size(501, 77);
            this.addPessoaEndereco.TabIndex = 12;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(7, 101);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 20);
            this.label30.TabIndex = 10;
            this.label30.Text = "Email";
            // 
            // addPessoaEmail
            // 
            this.addPessoaEmail.Location = new System.Drawing.Point(6, 140);
            this.addPessoaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaEmail.Name = "addPessoaEmail";
            this.addPessoaEmail.Size = new System.Drawing.Size(335, 27);
            this.addPessoaEmail.TabIndex = 9;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(373, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 20);
            this.label31.TabIndex = 8;
            this.label31.Text = "Telemóvel";
            // 
            // addPessoaTelemovel
            // 
            this.addPessoaTelemovel.Location = new System.Drawing.Point(373, 140);
            this.addPessoaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaTelemovel.Name = "addPessoaTelemovel";
            this.addPessoaTelemovel.Size = new System.Drawing.Size(138, 27);
            this.addPessoaTelemovel.TabIndex = 7;
            // 
            // addPessoaNome
            // 
            this.addPessoaNome.Location = new System.Drawing.Point(172, 38);
            this.addPessoaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNome.Name = "addPessoaNome";
            this.addPessoaNome.Size = new System.Drawing.Size(335, 27);
            this.addPessoaNome.TabIndex = 6;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(172, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(50, 20);
            this.label32.TabIndex = 5;
            this.label32.Text = "Nome";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(94, 20);
            this.label33.TabIndex = 4;
            this.label33.Text = "Identificador";
            // 
            // addPessoaIdentificador
            // 
            this.addPessoaIdentificador.Location = new System.Drawing.Point(6, 37);
            this.addPessoaIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaIdentificador.Name = "addPessoaIdentificador";
            this.addPessoaIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addPessoaIdentificador.TabIndex = 3;
            // 
            // addEmpresa
            // 
            this.addEmpresa.Controls.Add(this.addEmpresaNIPC);
            this.addEmpresa.Controls.Add(this.label26);
            this.addEmpresa.Controls.Add(this.label25);
            this.addEmpresa.Controls.Add(this.addEmpresaEndereco);
            this.addEmpresa.Controls.Add(this.label24);
            this.addEmpresa.Controls.Add(this.addEmpresaEmail);
            this.addEmpresa.Controls.Add(this.label23);
            this.addEmpresa.Controls.Add(this.addEmpresaTelemovel);
            this.addEmpresa.Controls.Add(this.addEmpresaNome);
            this.addEmpresa.Controls.Add(this.label22);
            this.addEmpresa.Controls.Add(this.label21);
            this.addEmpresa.Controls.Add(this.addEmpresaIdentificador);
            this.addEmpresa.Location = new System.Drawing.Point(0, 56);
            this.addEmpresa.Name = "addEmpresa";
            this.addEmpresa.Size = new System.Drawing.Size(879, 388);
            this.addEmpresa.TabIndex = 12;
            // 
            // addEmpresaNIPC
            // 
            this.addEmpresaNIPC.Location = new System.Drawing.Point(566, 37);
            this.addEmpresaNIPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaNIPC.Name = "addEmpresaNIPC";
            this.addEmpresaNIPC.Size = new System.Drawing.Size(94, 27);
            this.addEmpresaNIPC.TabIndex = 15;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(566, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 20);
            this.label26.TabIndex = 14;
            this.label26.Text = "NIPC";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 220);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(110, 20);
            this.label25.TabIndex = 13;
            this.label25.Text = "Endereço Atual";
            // 
            // addEmpresaEndereco
            // 
            this.addEmpresaEndereco.Location = new System.Drawing.Point(6, 244);
            this.addEmpresaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaEndereco.Multiline = true;
            this.addEmpresaEndereco.Name = "addEmpresaEndereco";
            this.addEmpresaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addEmpresaEndereco.Size = new System.Drawing.Size(501, 77);
            this.addEmpresaEndereco.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 116);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 20);
            this.label24.TabIndex = 10;
            this.label24.Text = "Email";
            // 
            // addEmpresaEmail
            // 
            this.addEmpresaEmail.Location = new System.Drawing.Point(6, 140);
            this.addEmpresaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaEmail.Name = "addEmpresaEmail";
            this.addEmpresaEmail.Size = new System.Drawing.Size(335, 27);
            this.addEmpresaEmail.TabIndex = 9;
            this.addEmpresaEmail.TextChanged += new System.EventHandler(this.addEmpresaEmail_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(735, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 20);
            this.label23.TabIndex = 8;
            this.label23.Text = "Telemóvel";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // addEmpresaTelemovel
            // 
            this.addEmpresaTelemovel.Location = new System.Drawing.Point(735, 37);
            this.addEmpresaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaTelemovel.Name = "addEmpresaTelemovel";
            this.addEmpresaTelemovel.Size = new System.Drawing.Size(138, 27);
            this.addEmpresaTelemovel.TabIndex = 7;
            this.addEmpresaTelemovel.TextChanged += new System.EventHandler(this.addEmpresaTelemovel_TextChanged);
            // 
            // addEmpresaNome
            // 
            this.addEmpresaNome.Location = new System.Drawing.Point(172, 38);
            this.addEmpresaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaNome.Name = "addEmpresaNome";
            this.addEmpresaNome.Size = new System.Drawing.Size(335, 27);
            this.addEmpresaNome.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(172, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 20);
            this.label22.TabIndex = 5;
            this.label22.Text = "Nome";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(94, 20);
            this.label21.TabIndex = 4;
            this.label21.Text = "Identificador";
            // 
            // addEmpresaIdentificador
            // 
            this.addEmpresaIdentificador.Location = new System.Drawing.Point(6, 37);
            this.addEmpresaIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaIdentificador.Name = "addEmpresaIdentificador";
            this.addEmpresaIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addEmpresaIdentificador.TabIndex = 3;
            // 
            // addFracao
            // 
            this.addFracao.Controls.Add(this.addFracaoZona);
            this.addFracao.Controls.Add(this.label49);
            this.addFracao.Controls.Add(this.addFracaoCondominio);
            this.addFracao.Controls.Add(this.label27);
            this.addFracao.Controls.Add(this.addFracaoLocalizacao);
            this.addFracao.Controls.Add(this.label20);
            this.addFracao.Controls.Add(this.addFracaoProprietario);
            this.addFracao.Controls.Add(this.label19);
            this.addFracao.Controls.Add(this.addFracaoArea);
            this.addFracao.Controls.Add(this.label18);
            this.addFracao.Controls.Add(this.label17);
            this.addFracao.Controls.Add(this.addFracaoIdentificador);
            this.addFracao.Location = new System.Drawing.Point(1, 57);
            this.addFracao.Name = "addFracao";
            this.addFracao.Size = new System.Drawing.Size(879, 305);
            this.addFracao.TabIndex = 3;
            // 
            // addFracaoZona
            // 
            this.addFracaoZona.Location = new System.Drawing.Point(696, 38);
            this.addFracaoZona.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoZona.Name = "addFracaoZona";
            this.addFracaoZona.Size = new System.Drawing.Size(118, 27);
            this.addFracaoZona.TabIndex = 16;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(696, 1);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 20);
            this.label49.TabIndex = 15;
            this.label49.Text = "Zona";
            // 
            // addFracaoCondominio
            // 
            this.addFracaoCondominio.Location = new System.Drawing.Point(520, 37);
            this.addFracaoCondominio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoCondominio.Name = "addFracaoCondominio";
            this.addFracaoCondominio.Size = new System.Drawing.Size(118, 27);
            this.addFracaoCondominio.TabIndex = 14;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(520, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 20);
            this.label27.TabIndex = 13;
            this.label27.Text = "Condomínio";
            // 
            // addFracaoLocalizacao
            // 
            this.addFracaoLocalizacao.Location = new System.Drawing.Point(6, 140);
            this.addFracaoLocalizacao.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoLocalizacao.Multiline = true;
            this.addFracaoLocalizacao.Name = "addFracaoLocalizacao";
            this.addFracaoLocalizacao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addFracaoLocalizacao.Size = new System.Drawing.Size(654, 147);
            this.addFracaoLocalizacao.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(346, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 20);
            this.label20.TabIndex = 9;
            this.label20.Text = "Proprietário";
            // 
            // addFracaoProprietario
            // 
            this.addFracaoProprietario.Location = new System.Drawing.Point(346, 38);
            this.addFracaoProprietario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoProprietario.Name = "addFracaoProprietario";
            this.addFracaoProprietario.Size = new System.Drawing.Size(94, 27);
            this.addFracaoProprietario.TabIndex = 8;
            this.addFracaoProprietario.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 116);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 20);
            this.label19.TabIndex = 7;
            this.label19.Text = "Localização";
            // 
            // addFracaoArea
            // 
            this.addFracaoArea.Location = new System.Drawing.Point(172, 37);
            this.addFracaoArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoArea.Name = "addFracaoArea";
            this.addFracaoArea.Size = new System.Drawing.Size(94, 27);
            this.addFracaoArea.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(172, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 20);
            this.label18.TabIndex = 4;
            this.label18.Text = "Área";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 3;
            this.label17.Text = "Identificador";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // addFracaoIdentificador
            // 
            this.addFracaoIdentificador.Location = new System.Drawing.Point(3, 38);
            this.addFracaoIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoIdentificador.Name = "addFracaoIdentificador";
            this.addFracaoIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addFracaoIdentificador.TabIndex = 2;
            // 
            // addCondominio
            // 
            this.addCondominio.Controls.Add(this.label16);
            this.addCondominio.Controls.Add(this.label15);
            this.addCondominio.Controls.Add(this.addCondominioEstado);
            this.addCondominio.Controls.Add(this.label14);
            this.addCondominio.Controls.Add(this.label13);
            this.addCondominio.Controls.Add(this.label12);
            this.addCondominio.Controls.Add(this.label11);
            this.addCondominio.Controls.Add(this.addCondominioInicio);
            this.addCondominio.Controls.Add(this.addCondominioFim);
            this.addCondominio.Controls.Add(this.addCondominioNome);
            this.addCondominio.Controls.Add(this.addCondominioSaldo);
            this.addCondominio.Controls.Add(this.addCondominioEndereco);
            this.addCondominio.Controls.Add(this.addCondominioNumRegistro);
            this.addCondominio.Controls.Add(this.label10);
            this.addCondominio.Controls.Add(this.addCondominioNumContribuinte);
            this.addCondominio.Controls.Add(this.label9);
            this.addCondominio.Location = new System.Drawing.Point(3, 56);
            this.addCondominio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominio.Name = "addCondominio";
            this.addCondominio.Size = new System.Drawing.Size(874, 427);
            this.addCondominio.TabIndex = 1;
            this.addCondominio.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 220);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 20);
            this.label16.TabIndex = 16;
            this.label16.Text = "Endereço";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(517, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 20);
            this.label15.TabIndex = 15;
            this.label15.Text = "Saldo";
            // 
            // addCondominioEstado
            // 
            this.addCondominioEstado.FormattingEnabled = true;
            this.addCondominioEstado.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.addCondominioEstado.Location = new System.Drawing.Point(694, 37);
            this.addCondominioEstado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioEstado.Name = "addCondominioEstado";
            this.addCondominioEstado.Size = new System.Drawing.Size(110, 28);
            this.addCondominioEstado.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(694, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 20);
            this.label14.TabIndex = 13;
            this.label14.Text = "Estado";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(517, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 20);
            this.label13.TabIndex = 12;
            this.label13.Text = "Fim do Exercício";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(0, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Nome";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(343, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "Inicio do Exercício";
            // 
            // addCondominioInicio
            // 
            this.addCondominioInicio.Location = new System.Drawing.Point(343, 37);
            this.addCondominioInicio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioInicio.Name = "addCondominioInicio";
            this.addCondominioInicio.Size = new System.Drawing.Size(138, 27);
            this.addCondominioInicio.TabIndex = 9;
            // 
            // addCondominioFim
            // 
            this.addCondominioFim.Location = new System.Drawing.Point(517, 37);
            this.addCondominioFim.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioFim.Name = "addCondominioFim";
            this.addCondominioFim.Size = new System.Drawing.Size(138, 27);
            this.addCondominioFim.TabIndex = 8;
            // 
            // addCondominioNome
            // 
            this.addCondominioNome.Location = new System.Drawing.Point(0, 153);
            this.addCondominioNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNome.Name = "addCondominioNome";
            this.addCondominioNome.Size = new System.Drawing.Size(481, 27);
            this.addCondominioNome.TabIndex = 7;
            // 
            // addCondominioSaldo
            // 
            this.addCondominioSaldo.Location = new System.Drawing.Point(517, 153);
            this.addCondominioSaldo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioSaldo.Name = "addCondominioSaldo";
            this.addCondominioSaldo.Size = new System.Drawing.Size(138, 27);
            this.addCondominioSaldo.TabIndex = 6;
            // 
            // addCondominioEndereco
            // 
            this.addCondominioEndereco.Location = new System.Drawing.Point(0, 257);
            this.addCondominioEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioEndereco.Multiline = true;
            this.addCondominioEndereco.Name = "addCondominioEndereco";
            this.addCondominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addCondominioEndereco.Size = new System.Drawing.Size(654, 147);
            this.addCondominioEndereco.TabIndex = 5;
            // 
            // addCondominioNumRegistro
            // 
            this.addCondominioNumRegistro.Location = new System.Drawing.Point(169, 37);
            this.addCondominioNumRegistro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNumRegistro.Name = "addCondominioNumRegistro";
            this.addCondominioNumRegistro.Size = new System.Drawing.Size(138, 27);
            this.addCondominioNumRegistro.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(169, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "Número Registro";
            // 
            // addCondominioNumContribuinte
            // 
            this.addCondominioNumContribuinte.Location = new System.Drawing.Point(0, 37);
            this.addCondominioNumContribuinte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNumContribuinte.Name = "addCondominioNumContribuinte";
            this.addCondominioNumContribuinte.Size = new System.Drawing.Size(138, 27);
            this.addCondominioNumContribuinte.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(149, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Número Contribuinte";
            // 
            // addZona
            // 
            this.addZona.Controls.Add(this.addZonaDesignacao);
            this.addZona.Controls.Add(this.label48);
            this.addZona.Controls.Add(this.addZonaCodigo);
            this.addZona.Controls.Add(this.label47);
            this.addZona.Location = new System.Drawing.Point(1, 56);
            this.addZona.Name = "addZona";
            this.addZona.Size = new System.Drawing.Size(877, 120);
            this.addZona.TabIndex = 4;
            this.addZona.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // addZonaDesignacao
            // 
            this.addZonaDesignacao.Location = new System.Drawing.Point(198, 49);
            this.addZonaDesignacao.Name = "addZonaDesignacao";
            this.addZonaDesignacao.Size = new System.Drawing.Size(553, 27);
            this.addZonaDesignacao.TabIndex = 19;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(198, 14);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(87, 20);
            this.label48.TabIndex = 18;
            this.label48.Text = "Designação";
            // 
            // addZonaCodigo
            // 
            this.addZonaCodigo.Location = new System.Drawing.Point(6, 49);
            this.addZonaCodigo.Name = "addZonaCodigo";
            this.addZonaCodigo.Size = new System.Drawing.Size(125, 27);
            this.addZonaCodigo.TabIndex = 17;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 14);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(58, 20);
            this.label47.TabIndex = 16;
            this.label47.Text = "Código";
            // 
            // addServico
            // 
            this.addServico.Controls.Add(this.addServicoPagamento);
            this.addServico.Controls.Add(this.label46);
            this.addServico.Controls.Add(this.addServicoHoras);
            this.addServico.Controls.Add(this.label45);
            this.addServico.Controls.Add(this.addServicoCusto);
            this.addServico.Controls.Add(this.label44);
            this.addServico.Controls.Add(this.addServicoDesignacao);
            this.addServico.Controls.Add(this.label43);
            this.addServico.Controls.Add(this.addServicoCodigo);
            this.addServico.Controls.Add(this.Código);
            this.addServico.Location = new System.Drawing.Point(1, 56);
            this.addServico.Name = "addServico";
            this.addServico.Size = new System.Drawing.Size(881, 196);
            this.addServico.TabIndex = 19;
            // 
            // addServicoPagamento
            // 
            this.addServicoPagamento.FormattingEnabled = true;
            this.addServicoPagamento.Items.AddRange(new object[] {
            "Dinheiro Vivo",
            "Cartão"});
            this.addServicoPagamento.Location = new System.Drawing.Point(436, 153);
            this.addServicoPagamento.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addServicoPagamento.Name = "addServicoPagamento";
            this.addServicoPagamento.Size = new System.Drawing.Size(138, 28);
            this.addServicoPagamento.TabIndex = 4;
            this.addServicoPagamento.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(435, 118);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(139, 20);
            this.label46.TabIndex = 18;
            this.label46.Text = "Tipo de Pagamento";
            // 
            // addServicoHoras
            // 
            this.addServicoHoras.Location = new System.Drawing.Point(220, 153);
            this.addServicoHoras.Name = "addServicoHoras";
            this.addServicoHoras.Size = new System.Drawing.Size(125, 27);
            this.addServicoHoras.TabIndex = 17;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(220, 118);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(48, 20);
            this.label45.TabIndex = 16;
            this.label45.Text = "Horas";
            // 
            // addServicoCusto
            // 
            this.addServicoCusto.Location = new System.Drawing.Point(10, 153);
            this.addServicoCusto.Name = "addServicoCusto";
            this.addServicoCusto.Size = new System.Drawing.Size(125, 27);
            this.addServicoCusto.TabIndex = 15;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(10, 118);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(46, 20);
            this.label44.TabIndex = 14;
            this.label44.Text = "Custo";
            // 
            // addServicoDesignacao
            // 
            this.addServicoDesignacao.Location = new System.Drawing.Point(220, 49);
            this.addServicoDesignacao.Name = "addServicoDesignacao";
            this.addServicoDesignacao.Size = new System.Drawing.Size(403, 27);
            this.addServicoDesignacao.TabIndex = 13;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(220, 20);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(87, 20);
            this.label43.TabIndex = 12;
            this.label43.Text = "Designação";
            // 
            // addServicoCodigo
            // 
            this.addServicoCodigo.Location = new System.Drawing.Point(10, 49);
            this.addServicoCodigo.Name = "addServicoCodigo";
            this.addServicoCodigo.Size = new System.Drawing.Size(125, 27);
            this.addServicoCodigo.TabIndex = 11;
            // 
            // Código
            // 
            this.Código.AutoSize = true;
            this.Código.Location = new System.Drawing.Point(10, 14);
            this.Código.Name = "Código";
            this.Código.Size = new System.Drawing.Size(58, 20);
            this.Código.TabIndex = 10;
            this.Código.Text = "Código";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.viewAdd);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.viewAdd.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.CondominoEmpresa.ResumeLayout(false);
            this.CondominoEmpresa.PerformLayout();
            this.ProprietarioEmpresa.ResumeLayout(false);
            this.ProprietarioEmpresa.PerformLayout();
            this.CondominoPessoa.ResumeLayout(false);
            this.CondominoPessoa.PerformLayout();
            this.ProprietarioPessoa.ResumeLayout(false);
            this.ProprietarioPessoa.PerformLayout();
            this.fracaoPainel.ResumeLayout(false);
            this.fracaoPainel.PerformLayout();
            this.condominioPainel.ResumeLayout(false);
            this.condominioPainel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.addSeguro.ResumeLayout(false);
            this.addSeguro.PerformLayout();
            this.addPessoa.ResumeLayout(false);
            this.addPessoa.PerformLayout();
            this.addEmpresa.ResumeLayout(false);
            this.addEmpresa.PerformLayout();
            this.addFracao.ResumeLayout(false);
            this.addFracao.PerformLayout();
            this.addCondominio.ResumeLayout(false);
            this.addCondominio.PerformLayout();
            this.addZona.ResumeLayout(false);
            this.addZona.PerformLayout();
            this.addServico.ResumeLayout(false);
            this.addServico.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl viewAdd;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox condominioListBox;
        private System.Windows.Forms.ComboBox attDropdown;
        private System.Windows.Forms.ListBox attListBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Panel fracaoPainel;
        private System.Windows.Forms.TextBox fracaoEndereco;
        private System.Windows.Forms.Label fracaoEnderecoText;
        private System.Windows.Forms.TextBox fracaoArea;
        private System.Windows.Forms.Label fracaoAreaText;
        private System.Windows.Forms.TextBox fracaoIdentificador;
        private System.Windows.Forms.Label fracaoIdentificadorText;
        private System.Windows.Forms.Panel condominioPainel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox condominioEstado;
        private System.Windows.Forms.TextBox condominioNumRegistro;
        private System.Windows.Forms.TextBox condominioNumContribuinte;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox condominioNome;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox condominioSaldo;
        private System.Windows.Forms.TextBox condominioFim;
        private System.Windows.Forms.TextBox condominioInicio;
        private System.Windows.Forms.TextBox condominioEndereco;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox condominioSearch;
        private System.Windows.Forms.ComboBox secAttDropdown;
        private System.Windows.Forms.ComboBox addType;
        private System.Windows.Forms.Panel addCondominio;
        private System.Windows.Forms.TextBox addCondominioNumContribuinte;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox addCondominioNumRegistro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox addCondominioInicio;
        private System.Windows.Forms.TextBox addCondominioFim;
        private System.Windows.Forms.TextBox addCondominioNome;
        private System.Windows.Forms.TextBox addCondominioSaldo;
        private System.Windows.Forms.TextBox addCondominioEndereco;
        private System.Windows.Forms.ComboBox addCondominioEstado;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Panel addFracao;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox addFracaoLocalizacao;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox addFracaoProprietario;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox addFracaoArea;
        private System.Windows.Forms.TextBox addFracaoIdentificador;
        private System.Windows.Forms.Panel addEmpresa;
        private System.Windows.Forms.TextBox addEmpresaNIPC;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox addEmpresaEmail;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox addEmpresaTelemovel;
        private System.Windows.Forms.TextBox addEmpresaNome;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox addEmpresaIdentificador;
        private System.Windows.Forms.TextBox addEmpresaEndereco;
        private System.Windows.Forms.TextBox addFracaoCondominio;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel addPessoa;
        private System.Windows.Forms.TextBox addPessoaNIF;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox addPessoaEndereco;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox addPessoaEmail;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox addPessoaTelemovel;
        private System.Windows.Forms.TextBox addPessoaNome;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox addPessoaIdentificador;
        private System.Windows.Forms.TextBox addPessoaDataNascimento;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox addPessoaGenero;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox addPessoaNumCC;
        private System.Windows.Forms.Panel addSeguro;
        private System.Windows.Forms.TextBox addSeguroTipo;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox addSeguroNome;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox addSeguroNumApolice;
        private System.Windows.Forms.TextBox addSeguroCapitalO;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox addSeguroDesignacao;
        private System.Windows.Forms.TextBox addSeguroCapitalF;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox addServicoPagamento;
        private System.Windows.Forms.Panel addServico;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox addServicoHoras;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox addServicoCusto;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox addServicoDesignacao;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox addServicoCodigo;
        private System.Windows.Forms.Label Código;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel addZona;
        private System.Windows.Forms.TextBox addZonaCodigo;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox addZonaDesignacao;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox addFracaoZona;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox addSeguroCondominio;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox addSeguroFracao;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Panel ProprietarioPessoa;
        private System.Windows.Forms.TextBox ProprietarioPessoaTelemovel;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox ProprietarioPessoaNome;
        private System.Windows.Forms.TextBox ProprietarioPessoaEndereco;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox ProprietarioPessoaID;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ListBox secAttListBox;
        private System.Windows.Forms.TextBox ProprietarioPessoaNumCC;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox ProprietarioPessoaEmail;
        private System.Windows.Forms.TextBox ProprietarioPessoaG;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox ProprietarioPessoaNIF;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox ProprietarioPessoaDataNascimento;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox ProprietarioPessoaFE;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox ProprietarioPessoaIE;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel CondominoPessoa;
        private System.Windows.Forms.TextBox CondominoPessoaFE;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox CondominoPessoaIE;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox CondominoPessoaDataNasc;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox CondominoPessoaNIF;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox CondominoPessoaEmail;
        private System.Windows.Forms.TextBox CondominoPessoaG;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox CondominoPessoaNumCC;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox CondominoPessoaTelemovel;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox CondominoPessoaNome;
        private System.Windows.Forms.TextBox CondominoPessoaEndereco;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox CondominoPessoaID;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Panel ProprietarioEmpresa;
        private System.Windows.Forms.TextBox ProprietarioEmpresaFE;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox ProprietarioEmpresaIE;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox ProprietarioEmpresaEmail;
        private System.Windows.Forms.TextBox ProprietarioEmpresaTelemovel;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox ProprietarioEmpresaNome;
        private System.Windows.Forms.TextBox ProprietarioEmpresaEndereco;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox ProprietarioEmpresaID;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox ProprietarioEmpresaNIPC;
        private System.Windows.Forms.Panel CondominoEmpresa;
        private System.Windows.Forms.TextBox CondominoEmpresaNIPC;
        private System.Windows.Forms.TextBox CondominoEmpresaFE;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox CondominoEmpresaIE;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox CondominoEmpresaEmail;
        private System.Windows.Forms.TextBox CondominoEmpresaTelemovel;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox CondominoEmpresaNome;
        private System.Windows.Forms.TextBox CondominoEmpresaEndereco;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox CondominoEmpresaID;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label97;
    }
}

