﻿
namespace ProjetoAppV2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewAdd = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.secAttSearch = new System.Windows.Forms.TextBox();
            this.secAttDropdown = new System.Windows.Forms.ComboBox();
            this.secAttListBox = new System.Windows.Forms.ListBox();
            this.condominioSearch = new System.Windows.Forms.TextBox();
            this.attSearch = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.attDropdown = new System.Windows.Forms.ComboBox();
            this.attListBox = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.condominioListBox = new System.Windows.Forms.ListBox();
            this.fracaoPainel = new System.Windows.Forms.Panel();
            this.fracaoEndereco = new System.Windows.Forms.TextBox();
            this.fracaoEnderecoText = new System.Windows.Forms.Label();
            this.fracaoArea = new System.Windows.Forms.TextBox();
            this.fracaoAreaText = new System.Windows.Forms.Label();
            this.fracaoIdentificador = new System.Windows.Forms.TextBox();
            this.fracaoIdentificadorText = new System.Windows.Forms.Label();
            this.condominioPainel = new System.Windows.Forms.Panel();
            this.condominioEndereco = new System.Windows.Forms.TextBox();
            this.condominioSaldo = new System.Windows.Forms.TextBox();
            this.condominioFim = new System.Windows.Forms.TextBox();
            this.condominioInicio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.condominioNome = new System.Windows.Forms.TextBox();
            this.condominioEstado = new System.Windows.Forms.TextBox();
            this.condominioNumRegistro = new System.Windows.Forms.TextBox();
            this.condominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.addButton = new System.Windows.Forms.Button();
            this.addType = new System.Windows.Forms.ComboBox();
            this.addFracao = new System.Windows.Forms.Panel();
            this.addEmpresa = new System.Windows.Forms.Panel();
            this.addEmpresaNIPC = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.addEmpresaEndereco = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.addEmpresaEmail = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.addEmpresaTelemovel = new System.Windows.Forms.TextBox();
            this.addEmpresaNome = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.addEmpresaIdentificador = new System.Windows.Forms.TextBox();
            this.addFracaoCondominio = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.addFracaoLocalizacao = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.addFracaoProprietario = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.addFracaoArea = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.addFracaoIdentificador = new System.Windows.Forms.TextBox();
            this.addCondominio = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.addCondominioEstado = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.addCondominioInicio = new System.Windows.Forms.TextBox();
            this.addCondominioFim = new System.Windows.Forms.TextBox();
            this.addCondominioNome = new System.Windows.Forms.TextBox();
            this.addCondominioSaldo = new System.Windows.Forms.TextBox();
            this.addCondominioEndereco = new System.Windows.Forms.TextBox();
            this.addCondominioNumRegistro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.addCondominioNumContribuinte = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.addPessoa = new System.Windows.Forms.Panel();
            this.addPessoaNIF = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.addPessoaEndereco = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.addPessoaEmail = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.addPessoaTelemovel = new System.Windows.Forms.TextBox();
            this.addPessoaNome = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.addPessoaIdentificador = new System.Windows.Forms.TextBox();
            this.addPessoaNumCC = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.addPessoaGenero = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.addPessoaDataNascimento = new System.Windows.Forms.TextBox();
            this.viewAdd.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.fracaoPainel.SuspendLayout();
            this.condominioPainel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.addFracao.SuspendLayout();
            this.addEmpresa.SuspendLayout();
            this.addCondominio.SuspendLayout();
            this.addPessoa.SuspendLayout();
            this.SuspendLayout();
            // 
            // viewAdd
            // 
            this.viewAdd.Controls.Add(this.tabPage1);
            this.viewAdd.Controls.Add(this.tabPage2);
            this.viewAdd.Location = new System.Drawing.Point(14, 16);
            this.viewAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.viewAdd.Name = "viewAdd";
            this.viewAdd.SelectedIndex = 0;
            this.viewAdd.Size = new System.Drawing.Size(887, 568);
            this.viewAdd.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.secAttSearch);
            this.tabPage1.Controls.Add(this.secAttDropdown);
            this.tabPage1.Controls.Add(this.secAttListBox);
            this.tabPage1.Controls.Add(this.condominioSearch);
            this.tabPage1.Controls.Add(this.attSearch);
            this.tabPage1.Controls.Add(this.cancelButton);
            this.tabPage1.Controls.Add(this.saveButton);
            this.tabPage1.Controls.Add(this.editButton);
            this.tabPage1.Controls.Add(this.removeButton);
            this.tabPage1.Controls.Add(this.attDropdown);
            this.tabPage1.Controls.Add(this.attListBox);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.condominioListBox);
            this.tabPage1.Controls.Add(this.fracaoPainel);
            this.tabPage1.Controls.Add(this.condominioPainel);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(879, 535);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // secAttSearch
            // 
            this.secAttSearch.Location = new System.Drawing.Point(386, 44);
            this.secAttSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.secAttSearch.Name = "secAttSearch";
            this.secAttSearch.PlaceholderText = "Pesquisa";
            this.secAttSearch.Size = new System.Drawing.Size(114, 27);
            this.secAttSearch.TabIndex = 34;
            this.secAttSearch.Visible = false;
            // 
            // secAttDropdown
            // 
            this.secAttDropdown.FormattingEnabled = true;
            this.secAttDropdown.Location = new System.Drawing.Point(386, 4);
            this.secAttDropdown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.secAttDropdown.Name = "secAttDropdown";
            this.secAttDropdown.Size = new System.Drawing.Size(138, 28);
            this.secAttDropdown.TabIndex = 33;
            this.secAttDropdown.Text = "Atributos";
            this.secAttDropdown.Visible = false;
            this.secAttDropdown.SelectedIndexChanged += new System.EventHandler(this.secAttDropdown_SelectedIndexChanged);
            // 
            // secAttListBox
            // 
            this.secAttListBox.FormattingEnabled = true;
            this.secAttListBox.ItemHeight = 20;
            this.secAttListBox.Location = new System.Drawing.Point(386, 84);
            this.secAttListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.secAttListBox.Name = "secAttListBox";
            this.secAttListBox.Size = new System.Drawing.Size(138, 424);
            this.secAttListBox.TabIndex = 32;
            this.secAttListBox.Visible = false;
            // 
            // condominioSearch
            // 
            this.condominioSearch.Location = new System.Drawing.Point(3, 3);
            this.condominioSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioSearch.Name = "condominioSearch";
            this.condominioSearch.PlaceholderText = "Pesquisa";
            this.condominioSearch.Size = new System.Drawing.Size(114, 27);
            this.condominioSearch.TabIndex = 31;
            this.condominioSearch.TextChanged += new System.EventHandler(this.condominioSearch_TextChanged);
            // 
            // attSearch
            // 
            this.attSearch.Location = new System.Drawing.Point(241, 44);
            this.attSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.attSearch.Name = "attSearch";
            this.attSearch.PlaceholderText = "Pesquisa";
            this.attSearch.Size = new System.Drawing.Size(114, 27);
            this.attSearch.TabIndex = 26;
            this.attSearch.Visible = false;
            this.attSearch.TextChanged += new System.EventHandler(this.attSearch_TextChanged);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(666, 479);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(86, 31);
            this.cancelButton.TabIndex = 29;
            this.cancelButton.Text = "Cancelar";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Visible = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(771, 479);
            this.saveButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(86, 31);
            this.saveButton.TabIndex = 28;
            this.saveButton.Text = "Salvar";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Visible = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(771, 479);
            this.editButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(86, 31);
            this.editButton.TabIndex = 27;
            this.editButton.Text = "Editar";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Visible = false;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(666, 479);
            this.removeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(86, 31);
            this.removeButton.TabIndex = 20;
            this.removeButton.Text = "Remover";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Visible = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // attDropdown
            // 
            this.attDropdown.FormattingEnabled = true;
            this.attDropdown.Location = new System.Drawing.Point(241, 4);
            this.attDropdown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.attDropdown.Name = "attDropdown";
            this.attDropdown.Size = new System.Drawing.Size(138, 28);
            this.attDropdown.TabIndex = 11;
            this.attDropdown.Text = "Atributos";
            this.attDropdown.SelectedIndexChanged += new System.EventHandler(this.attDropdown_SelectedIndexChanged);
            // 
            // attListBox
            // 
            this.attListBox.FormattingEnabled = true;
            this.attListBox.ItemHeight = 20;
            this.attListBox.Location = new System.Drawing.Point(241, 84);
            this.attListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.attListBox.Name = "attListBox";
            this.attListBox.Size = new System.Drawing.Size(138, 424);
            this.attListBox.TabIndex = 12;
            this.attListBox.Visible = false;
            this.attListBox.SelectedIndexChanged += new System.EventHandler(this.attListBox_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(805, 545);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 13);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // condominioListBox
            // 
            this.condominioListBox.FormattingEnabled = true;
            this.condominioListBox.ItemHeight = 20;
            this.condominioListBox.Location = new System.Drawing.Point(3, 44);
            this.condominioListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioListBox.Name = "condominioListBox";
            this.condominioListBox.Size = new System.Drawing.Size(207, 464);
            this.condominioListBox.TabIndex = 10;
            this.condominioListBox.SelectedIndexChanged += new System.EventHandler(this.condominioListBox_SelectedIndexChanged);
            // 
            // fracaoPainel
            // 
            this.fracaoPainel.Controls.Add(this.fracaoEndereco);
            this.fracaoPainel.Controls.Add(this.fracaoEnderecoText);
            this.fracaoPainel.Controls.Add(this.fracaoArea);
            this.fracaoPainel.Controls.Add(this.fracaoAreaText);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificador);
            this.fracaoPainel.Controls.Add(this.fracaoIdentificadorText);
            this.fracaoPainel.Location = new System.Drawing.Point(531, 4);
            this.fracaoPainel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoPainel.Name = "fracaoPainel";
            this.fracaoPainel.Size = new System.Drawing.Size(343, 467);
            this.fracaoPainel.TabIndex = 21;
            this.fracaoPainel.Visible = false;
            // 
            // fracaoEndereco
            // 
            this.fracaoEndereco.Enabled = false;
            this.fracaoEndereco.Location = new System.Drawing.Point(24, 188);
            this.fracaoEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoEndereco.Multiline = true;
            this.fracaoEndereco.Name = "fracaoEndereco";
            this.fracaoEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.fracaoEndereco.Size = new System.Drawing.Size(316, 243);
            this.fracaoEndereco.TabIndex = 25;
            // 
            // fracaoEnderecoText
            // 
            this.fracaoEnderecoText.AutoSize = true;
            this.fracaoEnderecoText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoEnderecoText.Location = new System.Drawing.Point(24, 140);
            this.fracaoEnderecoText.Name = "fracaoEnderecoText";
            this.fracaoEnderecoText.Size = new System.Drawing.Size(71, 20);
            this.fracaoEnderecoText.TabIndex = 24;
            this.fracaoEnderecoText.Text = "Endereço";
            // 
            // fracaoArea
            // 
            this.fracaoArea.Enabled = false;
            this.fracaoArea.Location = new System.Drawing.Point(185, 79);
            this.fracaoArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoArea.Name = "fracaoArea";
            this.fracaoArea.Size = new System.Drawing.Size(86, 27);
            this.fracaoArea.TabIndex = 23;
            // 
            // fracaoAreaText
            // 
            this.fracaoAreaText.AutoSize = true;
            this.fracaoAreaText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoAreaText.Location = new System.Drawing.Point(185, 40);
            this.fracaoAreaText.Name = "fracaoAreaText";
            this.fracaoAreaText.Size = new System.Drawing.Size(73, 20);
            this.fracaoAreaText.TabIndex = 22;
            this.fracaoAreaText.Text = "Area (m²)";
            // 
            // fracaoIdentificador
            // 
            this.fracaoIdentificador.Enabled = false;
            this.fracaoIdentificador.Location = new System.Drawing.Point(24, 79);
            this.fracaoIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fracaoIdentificador.Name = "fracaoIdentificador";
            this.fracaoIdentificador.Size = new System.Drawing.Size(114, 27);
            this.fracaoIdentificador.TabIndex = 20;
            // 
            // fracaoIdentificadorText
            // 
            this.fracaoIdentificadorText.AutoSize = true;
            this.fracaoIdentificadorText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fracaoIdentificadorText.Location = new System.Drawing.Point(24, 40);
            this.fracaoIdentificadorText.Name = "fracaoIdentificadorText";
            this.fracaoIdentificadorText.Size = new System.Drawing.Size(94, 20);
            this.fracaoIdentificadorText.TabIndex = 21;
            this.fracaoIdentificadorText.Text = "Identificador";
            // 
            // condominioPainel
            // 
            this.condominioPainel.Controls.Add(this.condominioEndereco);
            this.condominioPainel.Controls.Add(this.condominioSaldo);
            this.condominioPainel.Controls.Add(this.condominioFim);
            this.condominioPainel.Controls.Add(this.condominioInicio);
            this.condominioPainel.Controls.Add(this.label8);
            this.condominioPainel.Controls.Add(this.label7);
            this.condominioPainel.Controls.Add(this.label6);
            this.condominioPainel.Controls.Add(this.condominioNome);
            this.condominioPainel.Controls.Add(this.condominioEstado);
            this.condominioPainel.Controls.Add(this.condominioNumRegistro);
            this.condominioPainel.Controls.Add(this.condominioNumContribuinte);
            this.condominioPainel.Controls.Add(this.label5);
            this.condominioPainel.Controls.Add(this.label4);
            this.condominioPainel.Controls.Add(this.label3);
            this.condominioPainel.Controls.Add(this.label2);
            this.condominioPainel.Controls.Add(this.label1);
            this.condominioPainel.Location = new System.Drawing.Point(241, 84);
            this.condominioPainel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioPainel.Name = "condominioPainel";
            this.condominioPainel.Size = new System.Drawing.Size(633, 387);
            this.condominioPainel.TabIndex = 26;
            this.condominioPainel.Visible = false;
            // 
            // condominioEndereco
            // 
            this.condominioEndereco.Enabled = false;
            this.condominioEndereco.Location = new System.Drawing.Point(0, 248);
            this.condominioEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioEndereco.Multiline = true;
            this.condominioEndereco.Name = "condominioEndereco";
            this.condominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.condominioEndereco.Size = new System.Drawing.Size(615, 117);
            this.condominioEndereco.TabIndex = 15;
            // 
            // condominioSaldo
            // 
            this.condominioSaldo.Enabled = false;
            this.condominioSaldo.Location = new System.Drawing.Point(462, 140);
            this.condominioSaldo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioSaldo.Name = "condominioSaldo";
            this.condominioSaldo.Size = new System.Drawing.Size(154, 27);
            this.condominioSaldo.TabIndex = 14;
            // 
            // condominioFim
            // 
            this.condominioFim.Enabled = false;
            this.condominioFim.Location = new System.Drawing.Point(488, 39);
            this.condominioFim.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioFim.Name = "condominioFim";
            this.condominioFim.Size = new System.Drawing.Size(127, 27);
            this.condominioFim.TabIndex = 13;
            // 
            // condominioInicio
            // 
            this.condominioInicio.Enabled = false;
            this.condominioInicio.Location = new System.Drawing.Point(339, 40);
            this.condominioInicio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioInicio.Name = "condominioInicio";
            this.condominioInicio.Size = new System.Drawing.Size(127, 27);
            this.condominioInicio.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(462, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Saldo (€)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(488, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Fim Exercício";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(339, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Início Exercício";
            // 
            // condominioNome
            // 
            this.condominioNome.Enabled = false;
            this.condominioNome.Location = new System.Drawing.Point(0, 140);
            this.condominioNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNome.Name = "condominioNome";
            this.condominioNome.Size = new System.Drawing.Size(437, 27);
            this.condominioNome.TabIndex = 8;
            // 
            // condominioEstado
            // 
            this.condominioEstado.Enabled = false;
            this.condominioEstado.Location = new System.Drawing.Point(243, 40);
            this.condominioEstado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioEstado.Name = "condominioEstado";
            this.condominioEstado.Size = new System.Drawing.Size(76, 27);
            this.condominioEstado.TabIndex = 7;
            // 
            // condominioNumRegistro
            // 
            this.condominioNumRegistro.Enabled = false;
            this.condominioNumRegistro.Location = new System.Drawing.Point(161, 40);
            this.condominioNumRegistro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNumRegistro.Name = "condominioNumRegistro";
            this.condominioNumRegistro.Size = new System.Drawing.Size(62, 27);
            this.condominioNumRegistro.TabIndex = 6;
            // 
            // condominioNumContribuinte
            // 
            this.condominioNumContribuinte.Enabled = false;
            this.condominioNumContribuinte.Location = new System.Drawing.Point(0, 40);
            this.condominioNumContribuinte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.condominioNumContribuinte.Name = "condominioNumContribuinte";
            this.condominioNumContribuinte.Size = new System.Drawing.Size(138, 27);
            this.condominioNumContribuinte.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(243, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Estado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Endereço";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número Contribuinte";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.addButton);
            this.tabPage2.Controls.Add(this.addType);
            this.tabPage2.Controls.Add(this.addFracao);
            this.tabPage2.Controls.Add(this.addCondominio);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(879, 535);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(789, 491);
            this.addButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(86, 31);
            this.addButton.TabIndex = 2;
            this.addButton.Text = "Adicionar";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // addType
            // 
            this.addType.FormattingEnabled = true;
            this.addType.Items.AddRange(new object[] {
            "Condomínio",
            "Fração"});
            this.addType.Location = new System.Drawing.Point(3, 4);
            this.addType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addType.Name = "addType";
            this.addType.Size = new System.Drawing.Size(138, 28);
            this.addType.TabIndex = 0;
            this.addType.SelectedIndexChanged += new System.EventHandler(this.addType_SelectedIndexChanged);
            // 
            // addFracao
            // 
            this.addFracao.Controls.Add(this.addEmpresa);
            this.addFracao.Controls.Add(this.addFracaoCondominio);
            this.addFracao.Controls.Add(this.label27);
            this.addFracao.Controls.Add(this.addFracaoLocalizacao);
            this.addFracao.Controls.Add(this.label20);
            this.addFracao.Controls.Add(this.addFracaoProprietario);
            this.addFracao.Controls.Add(this.label19);
            this.addFracao.Controls.Add(this.addFracaoArea);
            this.addFracao.Controls.Add(this.label18);
            this.addFracao.Controls.Add(this.label17);
            this.addFracao.Controls.Add(this.addFracaoIdentificador);
            this.addFracao.Location = new System.Drawing.Point(0, 56);
            this.addFracao.Name = "addFracao";
            this.addFracao.Size = new System.Drawing.Size(879, 424);
            this.addFracao.TabIndex = 3;
            // 
            // addEmpresa
            // 
            this.addEmpresa.Controls.Add(this.addPessoa);
            this.addEmpresa.Controls.Add(this.addEmpresaNIPC);
            this.addEmpresa.Controls.Add(this.label26);
            this.addEmpresa.Controls.Add(this.label25);
            this.addEmpresa.Controls.Add(this.addEmpresaEndereco);
            this.addEmpresa.Controls.Add(this.label24);
            this.addEmpresa.Controls.Add(this.addEmpresaEmail);
            this.addEmpresa.Controls.Add(this.label23);
            this.addEmpresa.Controls.Add(this.addEmpresaTelemovel);
            this.addEmpresa.Controls.Add(this.addEmpresaNome);
            this.addEmpresa.Controls.Add(this.label22);
            this.addEmpresa.Controls.Add(this.label21);
            this.addEmpresa.Controls.Add(this.addEmpresaIdentificador);
            this.addEmpresa.Location = new System.Drawing.Point(0, 0);
            this.addEmpresa.Name = "addEmpresa";
            this.addEmpresa.Size = new System.Drawing.Size(879, 428);
            this.addEmpresa.TabIndex = 12;
            // 
            // addEmpresaNIPC
            // 
            this.addEmpresaNIPC.Location = new System.Drawing.Point(566, 37);
            this.addEmpresaNIPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaNIPC.Name = "addEmpresaNIPC";
            this.addEmpresaNIPC.Size = new System.Drawing.Size(94, 27);
            this.addEmpresaNIPC.TabIndex = 15;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(566, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 20);
            this.label26.TabIndex = 14;
            this.label26.Text = "NIPC";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 220);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(110, 20);
            this.label25.TabIndex = 13;
            this.label25.Text = "Endereço Atual";
            // 
            // addEmpresaEndereco
            // 
            this.addEmpresaEndereco.Location = new System.Drawing.Point(6, 244);
            this.addEmpresaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaEndereco.Multiline = true;
            this.addEmpresaEndereco.Name = "addEmpresaEndereco";
            this.addEmpresaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addEmpresaEndereco.Size = new System.Drawing.Size(501, 77);
            this.addEmpresaEndereco.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 116);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 20);
            this.label24.TabIndex = 10;
            this.label24.Text = "Email";
            // 
            // addEmpresaEmail
            // 
            this.addEmpresaEmail.Location = new System.Drawing.Point(6, 140);
            this.addEmpresaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaEmail.Name = "addEmpresaEmail";
            this.addEmpresaEmail.Size = new System.Drawing.Size(335, 27);
            this.addEmpresaEmail.TabIndex = 9;
            this.addEmpresaEmail.TextChanged += new System.EventHandler(this.addEmpresaEmail_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(735, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 20);
            this.label23.TabIndex = 8;
            this.label23.Text = "Telemóvel";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // addEmpresaTelemovel
            // 
            this.addEmpresaTelemovel.Location = new System.Drawing.Point(735, 37);
            this.addEmpresaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaTelemovel.Name = "addEmpresaTelemovel";
            this.addEmpresaTelemovel.Size = new System.Drawing.Size(138, 27);
            this.addEmpresaTelemovel.TabIndex = 7;
            this.addEmpresaTelemovel.TextChanged += new System.EventHandler(this.addEmpresaTelemovel_TextChanged);
            // 
            // addEmpresaNome
            // 
            this.addEmpresaNome.Location = new System.Drawing.Point(172, 38);
            this.addEmpresaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaNome.Name = "addEmpresaNome";
            this.addEmpresaNome.Size = new System.Drawing.Size(335, 27);
            this.addEmpresaNome.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(172, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 20);
            this.label22.TabIndex = 5;
            this.label22.Text = "Nome";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(94, 20);
            this.label21.TabIndex = 4;
            this.label21.Text = "Identificador";
            // 
            // addEmpresaIdentificador
            // 
            this.addEmpresaIdentificador.Location = new System.Drawing.Point(6, 37);
            this.addEmpresaIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEmpresaIdentificador.Name = "addEmpresaIdentificador";
            this.addEmpresaIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addEmpresaIdentificador.TabIndex = 3;
            // 
            // addFracaoCondominio
            // 
            this.addFracaoCondominio.Location = new System.Drawing.Point(520, 37);
            this.addFracaoCondominio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoCondominio.Name = "addFracaoCondominio";
            this.addFracaoCondominio.Size = new System.Drawing.Size(118, 27);
            this.addFracaoCondominio.TabIndex = 14;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(520, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 20);
            this.label27.TabIndex = 13;
            this.label27.Text = "Condomínio";
            // 
            // addFracaoLocalizacao
            // 
            this.addFracaoLocalizacao.Location = new System.Drawing.Point(6, 140);
            this.addFracaoLocalizacao.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoLocalizacao.Multiline = true;
            this.addFracaoLocalizacao.Name = "addFracaoLocalizacao";
            this.addFracaoLocalizacao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addFracaoLocalizacao.Size = new System.Drawing.Size(654, 147);
            this.addFracaoLocalizacao.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(346, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 20);
            this.label20.TabIndex = 9;
            this.label20.Text = "Proprietário";
            // 
            // addFracaoProprietario
            // 
            this.addFracaoProprietario.Location = new System.Drawing.Point(346, 38);
            this.addFracaoProprietario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoProprietario.Name = "addFracaoProprietario";
            this.addFracaoProprietario.Size = new System.Drawing.Size(94, 27);
            this.addFracaoProprietario.TabIndex = 8;
            this.addFracaoProprietario.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 116);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 20);
            this.label19.TabIndex = 7;
            this.label19.Text = "Localização";
            // 
            // addFracaoArea
            // 
            this.addFracaoArea.Location = new System.Drawing.Point(172, 37);
            this.addFracaoArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoArea.Name = "addFracaoArea";
            this.addFracaoArea.Size = new System.Drawing.Size(94, 27);
            this.addFracaoArea.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(172, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 20);
            this.label18.TabIndex = 4;
            this.label18.Text = "Área";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 3;
            this.label17.Text = "Identificador";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // addFracaoIdentificador
            // 
            this.addFracaoIdentificador.Location = new System.Drawing.Point(3, 38);
            this.addFracaoIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addFracaoIdentificador.Name = "addFracaoIdentificador";
            this.addFracaoIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addFracaoIdentificador.TabIndex = 2;
            // 
            // addCondominio
            // 
            this.addCondominio.Controls.Add(this.label16);
            this.addCondominio.Controls.Add(this.label15);
            this.addCondominio.Controls.Add(this.addCondominioEstado);
            this.addCondominio.Controls.Add(this.label14);
            this.addCondominio.Controls.Add(this.label13);
            this.addCondominio.Controls.Add(this.label12);
            this.addCondominio.Controls.Add(this.label11);
            this.addCondominio.Controls.Add(this.addCondominioInicio);
            this.addCondominio.Controls.Add(this.addCondominioFim);
            this.addCondominio.Controls.Add(this.addCondominioNome);
            this.addCondominio.Controls.Add(this.addCondominioSaldo);
            this.addCondominio.Controls.Add(this.addCondominioEndereco);
            this.addCondominio.Controls.Add(this.addCondominioNumRegistro);
            this.addCondominio.Controls.Add(this.label10);
            this.addCondominio.Controls.Add(this.addCondominioNumContribuinte);
            this.addCondominio.Controls.Add(this.label9);
            this.addCondominio.Location = new System.Drawing.Point(3, 56);
            this.addCondominio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominio.Name = "addCondominio";
            this.addCondominio.Size = new System.Drawing.Size(874, 427);
            this.addCondominio.TabIndex = 1;
            this.addCondominio.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 220);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 20);
            this.label16.TabIndex = 16;
            this.label16.Text = "Endereço";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(517, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 20);
            this.label15.TabIndex = 15;
            this.label15.Text = "Saldo";
            // 
            // addCondominioEstado
            // 
            this.addCondominioEstado.FormattingEnabled = true;
            this.addCondominioEstado.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.addCondominioEstado.Location = new System.Drawing.Point(694, 37);
            this.addCondominioEstado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioEstado.Name = "addCondominioEstado";
            this.addCondominioEstado.Size = new System.Drawing.Size(110, 28);
            this.addCondominioEstado.TabIndex = 14;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(694, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 20);
            this.label14.TabIndex = 13;
            this.label14.Text = "Estado";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(517, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 20);
            this.label13.TabIndex = 12;
            this.label13.Text = "Fim do Exercício";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(0, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Nome";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(343, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "Inicio do Exercício";
            // 
            // addCondominioInicio
            // 
            this.addCondominioInicio.Location = new System.Drawing.Point(343, 37);
            this.addCondominioInicio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioInicio.Name = "addCondominioInicio";
            this.addCondominioInicio.Size = new System.Drawing.Size(138, 27);
            this.addCondominioInicio.TabIndex = 9;
            // 
            // addCondominioFim
            // 
            this.addCondominioFim.Location = new System.Drawing.Point(517, 37);
            this.addCondominioFim.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioFim.Name = "addCondominioFim";
            this.addCondominioFim.Size = new System.Drawing.Size(138, 27);
            this.addCondominioFim.TabIndex = 8;
            // 
            // addCondominioNome
            // 
            this.addCondominioNome.Location = new System.Drawing.Point(0, 153);
            this.addCondominioNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNome.Name = "addCondominioNome";
            this.addCondominioNome.Size = new System.Drawing.Size(481, 27);
            this.addCondominioNome.TabIndex = 7;
            // 
            // addCondominioSaldo
            // 
            this.addCondominioSaldo.Location = new System.Drawing.Point(517, 153);
            this.addCondominioSaldo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioSaldo.Name = "addCondominioSaldo";
            this.addCondominioSaldo.Size = new System.Drawing.Size(138, 27);
            this.addCondominioSaldo.TabIndex = 6;
            // 
            // addCondominioEndereco
            // 
            this.addCondominioEndereco.Location = new System.Drawing.Point(0, 257);
            this.addCondominioEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioEndereco.Multiline = true;
            this.addCondominioEndereco.Name = "addCondominioEndereco";
            this.addCondominioEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addCondominioEndereco.Size = new System.Drawing.Size(654, 147);
            this.addCondominioEndereco.TabIndex = 5;
            // 
            // addCondominioNumRegistro
            // 
            this.addCondominioNumRegistro.Location = new System.Drawing.Point(169, 37);
            this.addCondominioNumRegistro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNumRegistro.Name = "addCondominioNumRegistro";
            this.addCondominioNumRegistro.Size = new System.Drawing.Size(138, 27);
            this.addCondominioNumRegistro.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(169, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "Número Registro";
            // 
            // addCondominioNumContribuinte
            // 
            this.addCondominioNumContribuinte.Location = new System.Drawing.Point(0, 37);
            this.addCondominioNumContribuinte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addCondominioNumContribuinte.Name = "addCondominioNumContribuinte";
            this.addCondominioNumContribuinte.Size = new System.Drawing.Size(138, 27);
            this.addCondominioNumContribuinte.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(149, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Número Contribuinte";
            // 
            // addPessoa
            // 
            this.addPessoa.Controls.Add(this.addPessoaDataNascimento);
            this.addPessoa.Controls.Add(this.label36);
            this.addPessoa.Controls.Add(this.label35);
            this.addPessoa.Controls.Add(this.addPessoaGenero);
            this.addPessoa.Controls.Add(this.label34);
            this.addPessoa.Controls.Add(this.addPessoaNumCC);
            this.addPessoa.Controls.Add(this.addPessoaNIF);
            this.addPessoa.Controls.Add(this.label28);
            this.addPessoa.Controls.Add(this.label29);
            this.addPessoa.Controls.Add(this.addPessoaEndereco);
            this.addPessoa.Controls.Add(this.label30);
            this.addPessoa.Controls.Add(this.addPessoaEmail);
            this.addPessoa.Controls.Add(this.label31);
            this.addPessoa.Controls.Add(this.addPessoaTelemovel);
            this.addPessoa.Controls.Add(this.addPessoaNome);
            this.addPessoa.Controls.Add(this.label32);
            this.addPessoa.Controls.Add(this.label33);
            this.addPessoa.Controls.Add(this.addPessoaIdentificador);
            this.addPessoa.Location = new System.Drawing.Point(-4, 0);
            this.addPessoa.Name = "addPessoa";
            this.addPessoa.Size = new System.Drawing.Size(888, 404);
            this.addPessoa.TabIndex = 16;
            // 
            // addPessoaNIF
            // 
            this.addPessoaNIF.Location = new System.Drawing.Point(566, 37);
            this.addPessoaNIF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNIF.Name = "addPessoaNIF";
            this.addPessoaNIF.Size = new System.Drawing.Size(109, 27);
            this.addPessoaNIF.TabIndex = 15;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(566, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 20);
            this.label28.TabIndex = 14;
            this.label28.Text = "NIF";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 220);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(110, 20);
            this.label29.TabIndex = 13;
            this.label29.Text = "Endereço Atual";
            // 
            // addPessoaEndereco
            // 
            this.addPessoaEndereco.Location = new System.Drawing.Point(6, 244);
            this.addPessoaEndereco.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaEndereco.Multiline = true;
            this.addPessoaEndereco.Name = "addPessoaEndereco";
            this.addPessoaEndereco.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.addPessoaEndereco.Size = new System.Drawing.Size(501, 77);
            this.addPessoaEndereco.TabIndex = 12;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(7, 101);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 20);
            this.label30.TabIndex = 10;
            this.label30.Text = "Email";
            // 
            // addPessoaEmail
            // 
            this.addPessoaEmail.Location = new System.Drawing.Point(6, 140);
            this.addPessoaEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaEmail.Name = "addPessoaEmail";
            this.addPessoaEmail.Size = new System.Drawing.Size(335, 27);
            this.addPessoaEmail.TabIndex = 9;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(373, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 20);
            this.label31.TabIndex = 8;
            this.label31.Text = "Telemóvel";
            // 
            // addPessoaTelemovel
            // 
            this.addPessoaTelemovel.Location = new System.Drawing.Point(373, 140);
            this.addPessoaTelemovel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaTelemovel.Name = "addPessoaTelemovel";
            this.addPessoaTelemovel.Size = new System.Drawing.Size(138, 27);
            this.addPessoaTelemovel.TabIndex = 7;
            // 
            // addPessoaNome
            // 
            this.addPessoaNome.Location = new System.Drawing.Point(172, 38);
            this.addPessoaNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNome.Name = "addPessoaNome";
            this.addPessoaNome.Size = new System.Drawing.Size(335, 27);
            this.addPessoaNome.TabIndex = 6;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(172, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(50, 20);
            this.label32.TabIndex = 5;
            this.label32.Text = "Nome";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(94, 20);
            this.label33.TabIndex = 4;
            this.label33.Text = "Identificador";
            // 
            // addPessoaIdentificador
            // 
            this.addPessoaIdentificador.Location = new System.Drawing.Point(6, 37);
            this.addPessoaIdentificador.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaIdentificador.Name = "addPessoaIdentificador";
            this.addPessoaIdentificador.Size = new System.Drawing.Size(94, 27);
            this.addPessoaIdentificador.TabIndex = 3;
            // 
            // addPessoaNumCC
            // 
            this.addPessoaNumCC.Location = new System.Drawing.Point(739, 37);
            this.addPessoaNumCC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaNumCC.Name = "addPessoaNumCC";
            this.addPessoaNumCC.Size = new System.Drawing.Size(109, 27);
            this.addPessoaNumCC.TabIndex = 16;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(739, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(106, 20);
            this.label34.TabIndex = 17;
            this.label34.Text = "Número de CC";
            // 
            // addPessoaGenero
            // 
            this.addPessoaGenero.Location = new System.Drawing.Point(566, 140);
            this.addPessoaGenero.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaGenero.Name = "addPessoaGenero";
            this.addPessoaGenero.Size = new System.Drawing.Size(109, 27);
            this.addPessoaGenero.TabIndex = 18;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(566, 101);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 20);
            this.label35.TabIndex = 19;
            this.label35.Text = "Género";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(739, 101);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(145, 20);
            this.label36.TabIndex = 20;
            this.label36.Text = "Data de Nascimento";
            // 
            // addPessoaDataNascimento
            // 
            this.addPessoaDataNascimento.Location = new System.Drawing.Point(739, 140);
            this.addPessoaDataNascimento.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoaDataNascimento.Name = "addPessoaDataNascimento";
            this.addPessoaDataNascimento.Size = new System.Drawing.Size(109, 27);
            this.addPessoaDataNascimento.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.viewAdd);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.viewAdd.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.fracaoPainel.ResumeLayout(false);
            this.fracaoPainel.PerformLayout();
            this.condominioPainel.ResumeLayout(false);
            this.condominioPainel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.addFracao.ResumeLayout(false);
            this.addFracao.PerformLayout();
            this.addEmpresa.ResumeLayout(false);
            this.addEmpresa.PerformLayout();
            this.addCondominio.ResumeLayout(false);
            this.addCondominio.PerformLayout();
            this.addPessoa.ResumeLayout(false);
            this.addPessoa.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl viewAdd;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox condominioListBox;
        private System.Windows.Forms.ComboBox attDropdown;
        private System.Windows.Forms.ListBox attListBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Panel fracaoPainel;
        private System.Windows.Forms.TextBox fracaoEndereco;
        private System.Windows.Forms.Label fracaoEnderecoText;
        private System.Windows.Forms.TextBox fracaoArea;
        private System.Windows.Forms.Label fracaoAreaText;
        private System.Windows.Forms.TextBox fracaoIdentificador;
        private System.Windows.Forms.Label fracaoIdentificadorText;
        private System.Windows.Forms.Panel condominioPainel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox condominioEstado;
        private System.Windows.Forms.TextBox condominioNumRegistro;
        private System.Windows.Forms.TextBox condominioNumContribuinte;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox condominioNome;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox condominioSaldo;
        private System.Windows.Forms.TextBox condominioFim;
        private System.Windows.Forms.TextBox condominioInicio;
        private System.Windows.Forms.TextBox condominioEndereco;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox attSearch;
        private System.Windows.Forms.TextBox condominioSearch;
        private System.Windows.Forms.TextBox secAttSearch;
        private System.Windows.Forms.ComboBox secAttDropdown;
        private System.Windows.Forms.ListBox secAttListBox;
        private System.Windows.Forms.ComboBox addType;
        private System.Windows.Forms.Panel addCondominio;
        private System.Windows.Forms.TextBox addCondominioNumContribuinte;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox addCondominioNumRegistro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox addCondominioInicio;
        private System.Windows.Forms.TextBox addCondominioFim;
        private System.Windows.Forms.TextBox addCondominioNome;
        private System.Windows.Forms.TextBox addCondominioSaldo;
        private System.Windows.Forms.TextBox addCondominioEndereco;
        private System.Windows.Forms.ComboBox addCondominioEstado;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Panel addFracao;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox addFracaoLocalizacao;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox addFracaoProprietario;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox addFracaoArea;
        private System.Windows.Forms.TextBox addFracaoIdentificador;
        private System.Windows.Forms.Panel addEmpresa;
        private System.Windows.Forms.TextBox addEmpresaNIPC;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox addEmpresaEmail;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox addEmpresaTelemovel;
        private System.Windows.Forms.TextBox addEmpresaNome;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox addEmpresaIdentificador;
        private System.Windows.Forms.TextBox addEmpresaEndereco;
        private System.Windows.Forms.TextBox addFracaoCondominio;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel addPessoa;
        private System.Windows.Forms.TextBox addPessoaNIF;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox addPessoaEndereco;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox addPessoaEmail;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox addPessoaTelemovel;
        private System.Windows.Forms.TextBox addPessoaNome;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox addPessoaIdentificador;
        private System.Windows.Forms.TextBox addPessoaDataNascimento;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox addPessoaGenero;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox addPessoaNumCC;
    }
}

